---
title: "Americanswers on 5 Live! Why is Donald Trump threatening to sue the BBC for $1 billion?"
source: BBC News
date: 2025-11-11
datetime: 2025-11-11 05:07
url: https://www.bbc.co.uk/sounds/play/p0mfxsk5?at_medium=RSS&at_campaign=rss
type: news-article
tags:
  - 뉴스
  - BBC News
  - bbc
  - americast
  - https
  - sounds
  - www
  - trump
  - anthony
  - news
---

# Americanswers on 5 Live! Why is Donald Trump threatening to sue the BBC for $1 billion?

| 속성 | 값 |
| --- | --- |
| **출처** | [[BBC News]] |
| **날짜** | 2025-11-11 05:07 |
| **원문링크** | [바로가기](https://www.bbc.co.uk/sounds/play/p0mfxsk5?at_medium=RSS&at_campaign=rss) |

## 📝 요약
> And how will the U.S. government shutdown end?

## 🏷️ 키워드
**영문 키워드**: `bbc` | `americast` | `https`

**태그**: #bbc #americast #https #sounds #www #trump

## 📰 본문

Available for over a year
President Donald Trump has threatened to sue the BBC for $1 billion over how the editing of his speech in a Panorama documentary, calling it "false and defamatory".

The BBC chair Samir Shah has apologised for an "error of judgement" over the edit, and said the BBC was considering how to respond to Trump.

Matt Chorley, Justin, Anthony and Marianna discuss what Trump actually said in his January 6th speech, Trump’s long battle with the mainstream media, and what this could mean for the BBC.

We also look at the US government shutdown, Elon Musk launching a rival to Wikipedia, and whether a return of Barack Obama to politics could be possible.

HOSTS: * Justin Webb, Radio 4 presenter * Anthony Zurcher, North America correspondent * Marianna Spring, Social Media Investigations correspondent GET IN TOUCH: * Join our online community: https://discord.gg/qSrxqNcmRB * Send us a message or voice note via WhatsApp to +44 330 123 9480 * Email Americast@bbc.co.uk * Or use #Americast This episode was made by Rufus Gray with Alix Pickles and Grace Reeve.

The technical producer was Ben Andrews. The series producer is Purvee Pattni. The senior news editor is Sam Bonham.

If you want to be notified every time we publish a new episode, please subscribe to us on BBC Sounds by hitting the subscribe button on the app. You can now listen to Americast on a smart speaker.

If you want to listen, just say "Ask BBC Sounds to play Americast”. It works on most smart speakers.
US Election Unspun: Sign up for Anthony’s BBC newsletter: https://www.bbc.co.uk/news/world-us-canada-68093155 Americast is part of the BBC News Podcasts family of podcasts.

The team that makes Americast also makes lots of other podcasts, including Newscast and Ukrainecast.
If you enjoy Americast (and if you're reading this then you hopefully do), then we think that you will enjoy some of our other pods too. See links below.

Newscast: https://www.bbc.co.uk/sounds/series/p05299nl Ukrainecast: https://www.bbc.co.uk/sounds/brand/p0bqztzm Radical: https://www.bbc.co.uk/sounds/brand/p0gg4k6r The Global Story: https://www.bbc.co.uk/sounds/brand/w13xtvsd

Programme Website

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - BBC News]]

생성일시: 2025-11-14 15:53:22