---
title: "Max Klymenko wins TikTok creator of the year for career ladder series"
source: BBC News
date: 2025-11-14
datetime: 2025-11-14 10:11
url: https://www.bbc.com/news/articles/c17p1z5ppq8o?at_medium=RSS&at_campaign=rss
type: news-article
tags:
  - 뉴스
  - BBC News
  - award
  - year
  - content
  - tiktok
  - max
  - creator
  - said
  - london
---

# Max Klymenko wins TikTok creator of the year for career ladder series

| 속성 | 값 |
| --- | --- |
| **출처** | [[BBC News]] |
| **날짜** | 2025-11-14 10:11 |
| **원문링크** | [바로가기](https://www.bbc.com/news/articles/c17p1z5ppq8o?at_medium=RSS&at_campaign=rss) |

## 📝 요약
> Max Klymenko won creator of the year while Bemi Orojuogun, better known as bus aunty, won video of the year.

## 🏷️ 키워드
**영문 키워드**: `award` | `year` | `content`

**태그**: #award #year #content #tiktok #max #creator

## 📰 본문

TikTok award winner Max: 'It takes me hours to make the content you scroll on the toilet'
5 hours ago Share Save Yasmin Rufo Magazine London Share Save
Getty Images Max Klymenko took home the coveted prize of creator of the year
A transport enthusiast, a beauty advocate and a mum teaching people how to raise an autistic child were among the winners of the second annual TikTok awards.

Hosted by TV presenter Aj Odudu at Magazine London, awards were handed out in 12 categories including fashion, travel, food and education.

And taking home the coveted prize of creator of the year was Max Klymenko, who is best known for his career ladder series, which he says is the most popular non-animated show in the world.

In case you've not seen it, Max sets up his stepladder in various public spaces and invites passers-by to join him standing on the ladder while he tries to guess their career with a series of yes/no questions.

Max came to the UK from Ukraine 14 years ago and said the reason he started creating content was because he found it impossible to get a job to get his own career going.

"I had a lot of anxiety and stress around finding a job so I created videos helping people know what jobs were available to them." Gold ladder in hand, Max, who has 8.5 million followers on TikTok, dedicated his award to his grandma in Ukraine who "has no electricity to follow along".

"I'm calling her right after this," he said, explaining that she used to log-in from different TikTok accounts when he first started creating content so it looked like he had more views.

The 29-year-old, who accepted his award from last year's winner Kyra-Mae Turner added that he was grateful his content was being recognised because "everything you see when you scroll on the toilet or in bed takes hours to make".

The nominees have a combined follower count of more than 83 million and the winners were voted for by five million people on the app.

Winning the award for video of the year was Bemi Orojuogun, better known as bus aunty.
Often seen smiling silently on TikToks as she stands at the side of a road or a depot – while a passing double-decker appears to narrowly miss hitting her – Orojuogun has turned her lifelong love of the London's transport network into a viral celebration of city life.

Getty Images Bemi thanked Transport for London, Stormzy and god for her award tonight
Her winning video has been viewed almost 50 million times and she now has collaborations with Burberry and Ikea.

The mental health nurse has become one of TikTok's most unexpected success stories and she admitted: "It's slightly overwhelming that everyone recognises me," but said is she is proud of what she's achieved.

She thanked Transport for London and Stormzy, saying that he propelled her to fame after re-posting one of her videos.

The 56-year-old grandma had a wonderful night making friends - including Nikki Lilly, the winner of the fashion and beauty creator of the year.

Nikki, who has 10 million TikTok followers, told the BBC that fashion, beauty and lifestyle content can be seen as "skin deep" but her content challenges those perceptions.

"I don't want to only make my social media a highlights reel," the 21-year-old said. "It's also me having surgeries, a chronic illness and me having a facial difference."

Third wheeling a new friendship... Bemi and Nikki have found a best friend in each other
After being diagnosed with an arteriovenous malformation, a rare life-threatening medical condition, at age six, she has used her platform to raise awareness and inspire others.

"As someone with a facial condition, I've never felt fully embraced in this space," she said while accepting her award. But she added, she has now found "so much safety" in the TikTok beauty world.

Another advocate creator is Tola and Kevin who won the "voice for change" award.
Getty Images Tola's content about raising an autistic child has seen her build up a global following
Tola and Kevin are a mother-son duo behind an account that posts candid videos of what it's like to raise a young adult with autism, striving to create content that raises awareness and promotes acceptance.

In tears, Tola said she was so grateful for the award and explained she started the account because she felt isolated when her son was first diagnosed with autism 16 years ago.

She's since built an "amazing community who love and support Kevin" which has helped the both of them immensely.

One of the most recognisable winners of the night was Charley Marlowe, a Radio 1 presenter, who won entertainment creator of the year.

Getty Images Charley's celebrity interviews and presenting work earned her the award for entertainment creator of the year

If you don't know her, you're likely to know her famous cackle which has become her trademark.
On the red carpet earlier in the night she told me "Win or lose, we're on the booze, so I'm having a good night anyway." She was in shock to have won the award and dedicated it to "every northern, working-class diva."

Full list of winners

## 📅 관련 노트
- 일간 정리: [[2025-11-14]]
- 출처별 정리: [[출처 - BBC News]]

생성일시: 2025-11-14 15:53:22