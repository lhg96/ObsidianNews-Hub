---
title: "Richard Burton: Wild Genius"
source: BBC News
date: 2025-11-10
datetime: 2025-11-10 15:00
url: https://www.bbc.co.uk/iplayer/episode/m002m46k/richard-burton-wild-genius?at_mid=deJpUJ9deb&at_campaign=Richard_Burton_Wild_Genius&at_medium=display_ad&at_campaign_type=owned&at_nation=NET&at_audience_id=SS&at_product=iplayer&at_brand=m002m46k&at_ptr_name=bbc&at_ptr_type=media&at_format=image&at_objective=consumption&at_link_title=Richard_Burton_Wild_Genius&at_bbc_team=BBC
type: news-article
tags:
  - 뉴스
  - BBC News
  - documentary
  - charting
  - highs
  - lows
  - richard
  - burton
  - life
  - times
---

# Richard Burton: Wild Genius

| 속성 | 값 |
| --- | --- |
| **출처** | [[BBC News]] |
| **날짜** | 2025-11-10 15:00 |
| **원문링크** | [바로가기](https://www.bbc.co.uk/iplayer/episode/m002m46k/richard-burton-wild-genius?at_mid=deJpUJ9deb&at_campaign=Richard_Burton_Wild_Genius&at_medium=display_ad&at_campaign_type=owned&at_nation=NET&at_audience_id=SS&at_product=iplayer&at_brand=m002m46k&at_ptr_name=bbc&at_ptr_type=media&at_format=image&at_objective=consumption&at_link_title=Richard_Burton_Wild_Genius&at_bbc_team=BBC) |

## 📝 요약
> The epic story of a Hollywood star whose life and talent blazed like no other.

## 🏷️ 키워드
**영문 키워드**: `documentary` | `charting` | `highs`

**태그**: #documentary #charting #highs #lows #richard #burton

## 📰 본문

Documentary charting the highs and lows of Richard Burton’s life and times - revealing an ongoing struggle with drink, fame, love and his own talent. More

## 📅 관련 노트
- 일간 정리: [[2025-11-10]]
- 출처별 정리: [[출처 - BBC News]]

생성일시: 2025-11-14 15:53:22