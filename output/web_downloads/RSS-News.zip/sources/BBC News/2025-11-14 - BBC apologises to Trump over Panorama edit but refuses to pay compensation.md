---
title: "BBC apologises to Trump over Panorama edit but refuses to pay compensation"
source: BBC News
date: 2025-11-14
datetime: 2025-11-14 14:08
url: https://www.bbc.com/news/articles/c874nw4g2zzo?at_medium=RSS&at_campaign=rss
type: news-article
tags:
  - 뉴스
  - BBC News
  - bbc
  - trump
  - said
  - speech
  - president
  - edit
  - panorama
  - programme
---

# BBC apologises to Trump over Panorama edit but refuses to pay compensation

| 속성 | 값 |
| --- | --- |
| **출처** | [[BBC News]] |
| **날짜** | 2025-11-14 14:08 |
| **원문링크** | [바로가기](https://www.bbc.com/news/articles/c874nw4g2zzo?at_medium=RSS&at_campaign=rss) |

## 📝 요약
> Lawyers for the US president have threatened to sue the corporation for $1bn (£759m).

## 🏷️ 키워드
**영문 키워드**: `bbc` | `trump` | `said`

**태그**: #bbc #trump #said #speech #president #edit

## 📰 본문

BBC apologises to Trump over Panorama edit but refuses to pay compensation
2 hours ago Share Save Noor Nanji Culture reporter Share Save
Reuters / AFP via Getty Images
The BBC has apologised to US President Donald Trump for a Panorama episode that spliced parts of his 6 January 2021 speech together, but rejected his demands for compensation.

The corporation said the edit had given "the mistaken impression that President Trump had made a direct call for violent action" and said it would not show the 2024 programme again.

Lawyers for Trump have threatened to sue the BBC for $1bn (£759m) in damages unless the corporation issues a retraction, apologises and compensates him.

The fallout from the scandal led to the resignations of BBC director general Tim Davie and head of news Deborah Turness on Sunday.

BBC News has approached the White House for comment. The apology comes hours after a second similarly edited clip, broadcast on Newsnight in 2022, was revealed by the Daily Telegraph.

In its Corrections and Clarifications section, published on Thursday evening, the BBC said the Panorama programme had been reviewed after criticism of how Trump's speech had been edited.

The BBC had been given a deadline of 22:00 GMT (17:00 EST) on Friday to respond.
"We accept that our edit unintentionally created the impression that we were showing a single continuous section of the speech, rather than excerpts from different points in the speech, and that this gave the mistaken impression that President Trump had made a direct call for violent action," the statement said.

Lawyers for the BBC have written to President Trump's legal team in response to a letter received on Sunday, a BBC spokesperson said.

"BBC chair Samir Shah has separately sent a personal letter to the White House making clear to President Trump that he and the corporation are sorry for the edit of the president's speech on 6 January 2021, which featured in the programme," they said.

They added: "While the BBC sincerely regrets the manner in which the video clip was edited, we strongly disagree there is a basis for a defamation claim."

In Trump's speech he said: "We're going to walk down to the Capitol, and we're going to cheer on our brave senators and congressmen and women." More than 50 minutes later in the speech, he said: "And we fight.

We fight like hell." In the Panorama programme the clip shows him as saying: "We're going to walk down to the Capitol... and I'll be there with you. And we fight.

We fight like hell." Speaking to Fox News, Trump said his speech had been "butchered" and the way it was presented had "defrauded" viewers. The BBC received the letter from Trump's lawyers on Sunday.

It demands a "full and fair retraction" of the documentary, an apology, and that the BBC "appropriately compensate President Trump for the harm caused".

Watch: How the BBC works... in under two minutes
In its letter to Trump's legal team, the BBC sets out five main arguments for why it does not think it has a case to answer First it says the BBC did not have the rights to, and did not, distribute the Panorama episode on its US channels.

When the documentary was available on BBC iPlayer, it was restricted to viewers in the UK. Secondly, it says the documentary did not cause Trump harm, as he was re-elected shortly after.

Thirdly, it says the clip was not designed to mislead, but just to shorten a long speech, and that the edit was not done with malice.

Fourthly, it says the clip was never meant to be considered in isolation. Rather, it was 12 seconds within an hour-long programme, which also contained lots of voices in support of Trump.

Finally, an opinion on a matter of public concern and political speech is heavily protected under defamation laws in the US.

A BBC insider said that internally, there is a strong belief in the case the corporation has put forward, and in its defence.

BBC News approached the Department for Culture, Media and Sport for comment, which said they would not be issuing a statement.

Liberal Democrats leader Sir Ed Davey urged the prime minister to "get on the phone to Trump" to put a stop to his lawsuit threat and "defend the impartiality and independence of the BBC".

Fresh claim of misleading edit

## 📅 관련 노트
- 일간 정리: [[2025-11-14]]
- 출처별 정리: [[출처 - BBC News]]

생성일시: 2025-11-14 15:53:22