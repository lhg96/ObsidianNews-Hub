---
title: "Renters’ Rights Act: No-fault evictions banned from May 2026"
source: BBC News
date: 2025-11-14
datetime: 2025-11-14 07:31
url: https://www.bbc.com/news/articles/c8x1n9rv809o?at_medium=RSS&at_campaign=rss
type: news-article
tags:
  - 뉴스
  - BBC News
  - said
  - landlords
  - tenants
  - landlord
  - rent
  - england
  - renters
  - changes
---

# Renters’ Rights Act: No-fault evictions banned from May 2026

| 속성 | 값 |
| --- | --- |
| **출처** | [[BBC News]] |
| **날짜** | 2025-11-14 07:31 |
| **원문링크** | [바로가기](https://www.bbc.com/news/articles/c8x1n9rv809o?at_medium=RSS&at_campaign=rss) |

## 📝 요약
> The government confirms timeline for reforms to England’s rental market, including ending bidding wars.

## 🏷️ 키워드
**영문 키워드**: `said` | `landlords` | `tenants`

**태그**: #said #landlords #tenants #landlord #rent #england

## 📰 본문

No-fault evictions to be banned in England from May
8 hours ago Share Save Tarah Welsh, housing reporter and Tara Mewawalla Share Save
Getty Images
No-fault evictions will be outlawed in England from 1 May, the government confirmed, as it set out the timeline for sweeping renters' reforms.

The changes also see the end of fixed-term tenancy contracts, as renters move onto so-called "rolling" agreements, as well as an end to "bidding wars" and clearer rules on having pets.

Landlords have said the reforms would increase the screening of prospective tenants and have spoken of nervousness around what happens when tenancies go wrong.

Housing Secretary Steve Reed said the government was "calling time" on "rogue landlords" by initiating a raft of measures in the Renters' Rights Act.

"We're now on a countdown of just months to that law coming in - so good landlords can get ready and bad landlords should clean up their act," he added.

Shadow housing secretary Sir James Cleverly said the reforms "will drive landlords from the market, reduce supply and send prices up for tenants".

He said that, "with a start date of May 2026, we are now set for a six-month fire sale with tenants forced out at short notice".

Approximately 4.4m households in England rented from a private landlord between 2021 to 2023. The new rules will affect more than 11 million people.

The Renters' Rights Act - described as the biggest shake-up to renting in England for more than 30 years - was formally approved at the end of October.

While many renters welcomed the introduction of the timeline, some landlords expressed concern about the speed of the changes.

Deadline to implement changes is 'not enough'
Ben Beadle, chief executive of the National Residential Landlords Association, said the deadline alone to implement the changes is "not enough".

He added: "We have argued consistently that landlords and property businesses need at least six months from the publication of regulations to ensure the sector is properly prepared for the biggest changes it has faced for over 40 years." From May, properties will be rented on a "periodic" or rolling basis, rather than under a fixed 12 or 24-month contract.

Tenants who want to leave can give two months' notice, which the government says will prevent tenants paying rent for substandard properties.

Landlords will no longer be able to evict tenants for complaining about poor conditions.
More than 11,000 households in England had their homes repossessed by bailiffs following a section 21 eviction in the year to June.

Victoria, 25, had to suspend studying for her degree after she received a section 21 eviction notice in March.

She was living in Durham while studying at the University of Northumbria and believes the eviction was partly due to complaints about the property's condition.

"I ended up having no choice but to move back in with my parents and I was devastated."
'Your safety net can be pulled away on a whim of the landlord'
Kerrie became homeless after reporting significant mould in her flat
Kerrie Portman, 27, became homeless after reporting significant mold in her Cambridgeshire flat to environmental health in 2020.

The council placed her in temporary accommodation while the landlord was told to address the issue, but she was still stuck paying rent.

She said: "I think it's outrageous that the landlord continued to charge me full rent...
ultimately, he didn't really face any obstacles." A few weeks after she moved back in, she was given a section 21 notice, making her homeless.

She would nap in public bathrooms, sleep on long bus routes and shower at her gym.
"I think it's so ridiculous that your whole safety net and foundation can be pulled away on a whim of the landlord," Kerrie said.

The mold was reported to Kerrie's landlord
Ten households in Hackney, East London, in houses that are all owned by the same landlord, said they had recently been issued with section 21 notices without reason.

One of the affected tenants, who did not want to give her name, said she was "really panicking".
"We were looking for a place this time last year and it took us three to four months to find one," she said.

The government confirmed that all section 21 notices issued before May will stand, but it said landlords must begin court repossession proceedings by 31 July 2026.

The overhaul of the current system means that, from 1 May, landlords will only be able to evict tenants in certain circumstances: if tenants damage a property, commit antisocial behaviour, or fall significantly behind paying the rent.

'Anti-landlord' legislation
Maureen Treadwell contacted BBC News with concerns about the new law. Her family rent out 10 properties in Hampshire.

"There are draconian fines if you get things wrong, so the whole thing feels anti-landlord," she said.

She raised her fears that, without reforms to the court system making it quicker to evict bad tenants, there will be an exodus of people who want to let their homes.

"Is it worth letting your house and then having a court fight to recover it, or a one-year delay? It's not worth it. So it will end up making the housing crisis worse."

Maureen Treadwell's family rent out 10 properties in Hampshire

## 📅 관련 노트
- 일간 정리: [[2025-11-14]]
- 출처별 정리: [[출처 - BBC News]]

생성일시: 2025-11-14 15:53:22