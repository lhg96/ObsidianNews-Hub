---
title: "Guitar Hero at 20 – how a plastic axe bridged the gap between rock generations"
source: The Guardian
date: 2025-11-08
datetime: 2025-11-08 19:00
url: https://www.theguardian.com/games/2025/nov/08/guitar-hero-at-20-gap-between-rock-generations-harmonix-redoctane
type: news-article
tags:
  - 뉴스
  - The Guardian
  - hero
  - guitar
  - games
  - says
  - rock
  - music
  - game
  - band
authors: Christopher Lord
---

# Guitar Hero at 20 – how a plastic axe bridged the gap between rock generations

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-08 19:00 |
| **저자** | Christopher Lord |
| **원문링크** | [바로가기](https://www.theguardian.com/games/2025/nov/08/guitar-hero-at-20-gap-between-rock-generations-harmonix-redoctane) |

## 📝 요약
> <p>Guitar Hero’s controllers let anyone become a  star in their own living room – and made the bands featured in the game household names again</p><p>It is 20 years since Guitar Hero was launched in North America, and with it, the tools for the everyday gamer to become a rock star. Not literally of course, but try telling that to someone who has nailed Free Bird’s four-minute guitar solo in front of a packed living-room audience.</p><p>Developed by Harmonix, published by RedOctane and inspired by Konami’s GuitarFreaks, Guitar Hero gave players a guitar-shaped controller with which to match coloured notes scrolling down the screen in time with a song. Each riff or sequence corresponded to specific notes, creating the feel of a genuine performance.</p> <a href="https://www.theguardian.com/games/2025/nov/08/guitar-hero-at-20-gap-between-rock-generations-harmonix-redoctane">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `hero` | `guitar` | `games`

**태그**: #hero #guitar #games #says #rock #music

## 📰 본문

It is 20 years since Guitar Hero was launched in North America, and with it, the tools for the everyday gamer to become a rock star.

Not literally of course, but try telling that to someone who has nailed Free Bird’s four-minute guitar solo in front of a packed living-room audience.

Developed by Harmonix, published by RedOctane and inspired by Konami’s GuitarFreaks, Guitar Hero gave players a guitar-shaped controller with which to match coloured notes scrolling down the screen in time with a song.

Each riff or sequence corresponded to specific notes, creating the feel of a genuine performance.
Harmonix had already tried its hand at rhythm games with the PlayStation 2 titles Frequency and Amplitude when it partnered with RedOctane, which was purchased by Activision in 2006.

Together they laid the foundations for an unlikely billion-dollar franchise that had a remarkable impact for many of the artists featured, introducing decades-old bands such as Cheap Trick, Kansas and Lynyrd Skynyrd to millions of younger players.

View image in fullscreen Strum-thing new … a line of people playing plastic guitars. Photograph: Johannes Eisele/AFP/Getty Images

Michael Dornbrook, former COO of Harmonix, recalls the initial financial challenges of licensing the recordings – even though the first two games mostly used cover versions – but also how their bargaining power shifted once the game was a hit.

“We rerecorded all the music because the dollar figure was so high,” he says. “Even with the publishing rights alone, it was nearly impossible.

We couldn’t get bands like the Who – RedOctane had virtually no money, and we were pretty convinced it would fail.

But once Guitar Hero took off, and record sales and radio play were going up, everyone wanted to be in.”

He adds: “One of the amazing things was how many parents got in touch and thanked us for introducing their kids to the music they loved. It became a multigenerational thing.”

Northern Irish blues-rock band the Answer had Never Too Late included on the 2008 game Guitar Hero World Tour.

Guitarist Paul Mahon remembers how the series brought classic rock back into vogue: “Guitar Hero offered a bigger, younger audience.

Generally this had been seen as music that was past it, but then when it was featured on the game and teenagers were finding it, suddenly it was cool.

That legitimised it, and got rid of the ‘dad rock’ tag. It gave all our music a new life.”
In 2008, the Answer’s debut album was still unreleased in the US, meaning the game was a key medium of discovery for the band as they went on a North American tour supporting AC/DC.

“Their crew were playing Never Too Late on the tour bus, and some of them knew us from Guitar Hero,” Mahon says.

View image in fullscreen Spin-off games such as Guitar Hero: Aerosmith were themed around the band. Photograph: ArcadeImages/Alamy

Rock’s heavyweight names soon capitalised on the series’ popularity, with Aerosmith, Metallica and Van Halen featuring in dedicated spin-off titles that focused on each band’s catalogue and associated lore, imagery and rock’n’roll mythology.

In the case of Guitar Hero: Aerosmith, it was said to have made the band more money than any of their studio albums did.

It sold well over half a million copies in its first week, while sales of Aerosmith’s music saw an increase of up to 40% at a time when the music business’s established order was already collapsing in a changing landscape.

The series continues to inspire nimble-fingered fanaticism among its fans.
Earlier this year, streamer CarnyJared completed an impressive attempt of DragonForce’s Through the Fire and Flames – a notoriously difficult power-metal song made popular by Guitar Hero – on Clone Hero, a freeware game with almost identical gameplay but an array of customisation options.

This track is challenging enough on expert mode, let alone played at double speed and without missing a single one of its near 4,000 notes. CarnyJared claimed it took nine months of practice.

View image in fullscreen Notoriously difficulty … DragonForce guitarist Herman Li. Photograph: Gary Miller/FilmMagic

A mindboggling feat, but at what point does one pick up an actual guitar? “It doesn’t really matter, because you can’t play [that song] in nine months!

There’s zero chance,” says DragonForce guitarist Herman Li, who considers the game world and the real world to be very separate. “Guitar Hero is a fun, fantasy thing.

If you play Call of Duty, that doesn’t mean you should pick up a real gun and go to war.”
DragonForce had already wrapped up a successful tour when Through the Fire and Flames was featured on Guitar Hero III: Legends of Rock, but Li says it made them a household name.

“I remember the record label calling to tell me that we were selling albums like crazy,” he says.
“It exploded when we next toured, and we were playing just before the headliners Slipknot and Disturbed on the Mayhem festival.”

In fact, DragonForce’s exposure from Guitar Hero was so immense that it has threatened to overshadow everything else the band has done. Last year, the song was used in a trailer for Despicable Me 4.

“In the past I thought differently, but I’ve made peace with it,” Li says.
“If you only listen to one DragonForce song, it’s totally cool – everyone’s got their own musical journey and I’m glad we’ve been part of people’s lives”.

The best marketing, whether it’s for cars, clothes or video games, goes further than selling something – it evokes a desire. Did Guitar Hero tap into that?

“That’s exactly what we were trying to create,” Dornbrook says. “That thrill of being a rock star on the stage.

From day one, Alex [Rigopulos] and Eran [Egozy], who co-founded Harmonix, felt that there’s an instinctive human desire to make music, and they wanted to use technology to allow people to do it”.

The majority of Guitar Hero games were released in just a five-year period between 2005 and 2010, including spin-offs DJ Hero, complete with a turntable controller, and Band Hero, the two games releasing a week apart in 2009: Dornbrook says “Activision is famous for burning out franchises, they tend to overdo it”.

After that, the publisher’s interest in plastic instruments died down, aside from a short-lived revival in 2015 with Guitar Hero Live.

Games such as Clone Hero and Fortnite Festival have kept the scene alive, and there’s set to be something from the original publisher on the way: RedOctane Games,, a new studio which has “entered production on its debut rhythm-based title”.

Original co-founders Kai and Charles Huang are both involved as special advisers. Is the world ready to embrace another game in the spirit of Guitar Hero?

“We thought those games could be like Madden where you can update every year,” Dornbrook says. “There’s so much new music that it could be evergreen, so I’ve always been optimistic.

There’s no reason why it can’t continue with new generations.”

## 📅 관련 노트
- 일간 정리: [[2025-11-08]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22