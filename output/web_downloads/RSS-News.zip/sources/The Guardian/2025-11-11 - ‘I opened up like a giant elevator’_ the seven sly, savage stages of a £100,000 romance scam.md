---
title: "‘I opened up like a giant elevator’: the seven sly, savage stages of a £100,000 romance scam"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 14:00
url: https://www.theguardian.com/lifeandstyle/2025/nov/11/seven-sly-savage-stages-of-a-romance-scam
type: news-article
tags:
  - 뉴스
  - The Guardian
  - says
  - elizabeth
  - sam
  - money
  - about
  - carter
  - victim
  - your
authors: Anna Moore
---

# ‘I opened up like a giant elevator’: the seven sly, savage stages of a £100,000 romance scam

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 14:00 |
| **저자** | Anna Moore |
| **원문링크** | [바로가기](https://www.theguardian.com/lifeandstyle/2025/nov/11/seven-sly-savage-stages-of-a-romance-scam) |

## 📝 요약
> <p>Last year, romance fraud rose 52% for over-55s in the UK. Victims often feel they’ve made a terrible mistake and are at fault – but really, they’ve been expertly groomed by criminals</p><p>In total, over two and a half years, Elizabeth gave £100,000 to “Sam”, the “man” she met online, who she thought she loved and loved her back. She emptied her savings account, pawned her late mother’s jewellery and took out bank loans. She became so overdrawn that she could barely afford food and lived mainly on soup.</p><p>She had sent this money, for all sorts of reasons, to a man she’d never met. The first was a $500 Amazon voucher because Sam, a consultant, was out on an oil rig and needed to buy a manual. Later, the rig required a new part; then the tanker transporting the oil ran into problems, too. She gave money to Sam’s daughter who was trapped in an abusive marriage. Finally, when Sam became ill, Elizabeth was contacted by his doctor and began paying Sam’s medical bills. “When this doctor messaged to tell me that Sam was in a coma, I remember thinking he had such a strange, unprofessional turn of phrase,” says Elizabeth. “He said, ‘I’m sorry to spill the beans.’” She breaks into laughter. “A doctor! How could I have been so gullible?”</p> <a href="https://www.theguardian.com/lifeandstyle/2025/nov/11/seven-sly-savage-stages-of-a-romance-scam">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `says` | `elizabeth` | `sam`

**태그**: #says #elizabeth #sam #money #about #carter

## 📰 본문

In total, over two and a half years, Elizabeth gave £100,000 to “Sam”, the “man” she met online, who she thought she loved and loved her back.

She emptied her savings account, pawned her late mother’s jewellery and took out bank loans. She became so overdrawn that she could barely afford food and lived mainly on soup.

She had sent this money, for all sorts of reasons, to a man she’d never met. The first was a $500 Amazon voucher because Sam, a consultant, was out on an oil rig and needed to buy a manual.

Later, the rig required a new part; then the tanker transporting the oil ran into problems, too. She gave money to Sam’s daughter who was trapped in an abusive marriage.

Finally, when Sam became ill, Elizabeth was contacted by his doctor and began paying Sam’s medical bills.

“When this doctor messaged to tell me that Sam was in a coma, I remember thinking he had such a strange, unprofessional turn of phrase,” says Elizabeth.

“He said, ‘I’m sorry to spill the beans.’” She breaks into laughter. “A doctor! How could I have been so gullible?”

The scam ended in August last year only because Elizabeth’s adult sons confronted her and broke the spell. Next came crashing waves of shock, along with shame, anger, fear and a strange, searing grief.

“I was mourning a person that didn’t exist,” she says.
I’m often asked: who falls for this? The answer is: anyone who’s human
She still feels all of these emotions, which is partly why she now laughs. (“If I didn’t laugh, I’d never stop crying.

Then I’d be no good to anyone.”) But she also laughs because, in hindsight, the stories she’d been spun now seem absurd.

How could a sharp, funny, intelligent woman who had worked for years in the travel industry and spoke three languages have fallen for them?

Elizabeth, 67, asks herself this question daily, but the latest warnings from Lloyds show she is one of many.

Over the past 12 months, romance scams reported by the bank’s customers aged over 55 rose by 52%.
More than £106m was lost to romance fraud in the UK over the last financial year – and this only covers reported cases.

According to Dr Elisabeth Carter, a criminologist and forensic linguist at Kingston University, London, asking how someone could have “fallen for it” is to misunderstand the crime.

“Even now, despite the numbers, warnings around romance fraud are along the lines of ‘don’t be fooled’,” she says. “We don’t tell people not to fall for a mugging or a sexual assault.

It blames the victim for somehow being negligent.”
In fact, says Carter, romance fraud is far closer to grooming and abuse than it is to theft or burglary.

“The methods used are intimately aligned with those we see in coercive control and domestic abuse,” she says.

“The victim’s reality becomes so distorted over weeks, months or years that the decisions they make seem rational and reasonable.

I’m often asked, ‘Who falls for this?’ The answer is: anyone who is human.”
View image in fullscreen ‘He wanted to know everything about me and I opened up like a giant elevator.’ Composite: Guardian Design/Juanmonino/Getty Images

Victim selection
“There’s no broad ‘vulnerable’ category, but there are situational vulnerabilities that we can all fall into across a lifespan, such as being bereaved, losing a job or moving to a new area,” says Carter.

All these might make someone more stressed and distracted, and more open to an online connection.
In Elizabeth’s case, she had left an abusive partner of 37 years, finally moving into her own home with her youngest son who was in his 20s. She was in the early stages of recovery when she met “Sam”.

“I certainly wasn’t looking for anyone,” she says. “I was on a Facebook site about dogs when this person started chatting to me about the weirdest thing.

He said that rabbits were eating his daughter’s plants. I sent him the Amazon link to a type of wire mesh.

I accepted his friend request and he later sent me a picture of the mesh being put up and thanking me.”

Love bombing and trauma bombing
Their rapport felt instant. “He got my sense of humour,” says Elizabeth. “I’m quite sarcastic and he’d bat that back at me. I love that.

It’s all my birthdays at once.” Sam claimed he was half American, half Norwegian, based in Texas.
He constantly sent photos of himself, an attractive, bearded, grey-haired man going to work, eating dinner, living his life. “He sent poems and memes.

He wanted to know everything about me and I opened up like a giant elevator.
I had so much to say about my ex, so he learned my vulnerabilities.” (A year later, when Sam said his daughter needed funds to escape an abusive husband, of course Elizabeth helped.)

The attention was intoxicating. “When I needed dental work, he was messaging in the waiting room, bigging me up. Someone was actually being kind. I’d never had that before.

I was spellbound.” Sam seemed vulnerable, too. “His wife had cheated on him,” says Elizabeth. “She was now with this other man, travelling the world.” Trust was important to Sam.

He wanted to know if Elizabeth had ever been unfaithful. Would she hurt him too?
This trauma bombing is key, says Carter. “Slowly, reticently, they reveal things that make themselves look really vulnerable after initially seeming very capable,” she says.

“It puts the burden of responsibility on the victim to keep the fraudster safe. It makes them misunderstand the power balance.

They feel responsible for the fraudster’s feelings, determined not to let them down at any cost.”
View image in fullscreen ‘Any time I heard the phone ping, I’d be like a puppy.’ Photograph: Tero Vesalainen/Getty Images

Sam “overshared”. “He told me all his life plans in huge detail, sending me work contracts, and then when he took out a loan and remortgaged his house, he showed me all that, too.

When he went for a job interview in California, he shared his location as he wanted me to see where he was. When he didn’t get the job, I’d feel all his disappointment.

He seemed like a hard-working man with big ambition, stretched to the limit.” His financial pressures began to feel like Elizabeth’s. “I felt part of it, and responsible for his life.”

After six months of messaging, and the occasional short call, Sam messaged, “I feel like a whole thing is happening here but I don’t want to scare you?” Then he wrote, “I love you.

Is that too much too soon?”
“My God, I was elated,” says Elizabeth. “I’d never heard anybody say that and mean it.” All this had happened without any requests for money.

Sleep deprivation
“Any time I heard the phone ping, I’d be like a puppy,” says Elizabeth. “If it was 2am, we could still text for four hours. I had him enabled so he was never muted, whatever time it was.

If I woke at dawn, I’d be a demented beast, checking my phone.”
“It feels romantic, but sleep deprivation really degrades your cognitive ability to think clearly and make good decisions,” says Carter.

“Victims don’t ever complain, as it feels like someone can’t get enough of you – but it leaves no room to think clearly about what’s going on, or even to talk to other people.”

Scripting, hyper-intimacy and isolation
Sam crept into every corner of Elizabeth’s life. He sent her music. “So many songs. The first was Sara Bareilles’ I Choose You.

I started listening to her albums on a loop.” She loved online games such as Word Chums – so Sam downloaded them and they played together. Food was another big topic.

“He’d go on about me eating, worried that I wasn’t eating enough,” she says. “He’d tell me what to eat and send recipes and pictures of his meals.”

Elizabeth sent him pictures, too. “Because of my last relationship, Sam was always telling me that I apologised too much,” she says.

“So we had this thing that every time I used the word ‘sorry’ in our messages, I had to send a photo as a forfeit. The awful thing is that he has a catalogue of photos of me now.

Some in my pyjamas, one in stockings and suspenders.” There was barely a moment that didn’t involve Sam. “I even started learning Norwegian,” she says.

“You’re not in the real world, you’re in this pretend, amazing world.
I still lived with my youngest son and he’d joke about how I’d talk to him for five minutes, then get this hazed look and zone out – because there was always something going on with Sam.”

“A lot of this is scripting the most basic things we do,” says Carter. “Eating. Sleeping. Our daily habits. Those are being controlled really early on.

It’s a short leap from ‘Eat this meal’ to ‘Send an iTunes voucher’.”
It also isolates the victim.
“It prevents anyone from stepping in with a reality check,” says Carter, “and when the demands for money start, it stops victims from seeking advice elsewhere.” Fraudsters typically urge victims to keep the relationship secret, often saying that no one else could ever understand it.

Sam didn’t do this – but still, the relationship’s intensity separated Elizabeth from her support system.

“My sons were pleased I’d met someone after everything their dad had put us all through,” she says. “They made me promise never to give him money.

I said of course I wouldn’t – so when I started to, I kept it secret.”
Dream building
“Ultimately, the plan was that when he came off his last job on the oil rig, I would fly to America to live happily ever after,” says Elizabeth. “It’s terrible.

I’d recently become a grandmother but I was happy to leave my family on the flip of a coin.”
View image in fullscreen ‘When he disappeared, I’d absolutely panic.’ Photograph: Pla2na/Getty Images

This final dream, this finishing line, propels romance fraud forward. “Everything is moving towards being together,” says Carter.

Fraudsters do all they can to make it real – planning holidays, sending links to the best hotels, asking victims to house-hunt for their future home.

They might escalate language, using terms such as ‘husband’ and ‘wife’ for one another. “For the victim, everything they do, any money they give, is moving them towards that end point,” says Carter.

Gaslighting and withdrawal
Sometimes Elizabeth raised questions. “Something wouldn’t make sense, like another request for money, or it could be something else.

How was he spending so much time in a certain country without running over his visa?
If I questioned anything, he’d turn it back on me so brilliantly.” (“I thought you trusted me?” “How can you say this?”) She wondered if the problem was her.

Had her previous relationship made her paranoid and suspicious?
More harrowing were the times Sam disappeared offline for days.
“I’d absolutely panic – my life just emptied.” According to Carter, this tactic guarantees future compliance: “After all the incredible love-bombing, they withdraw it and that silence feels terrifying for victims.

What’s happened? Is it over? What did they do wrong? When the fraudsters return with some story about urgently needing money, the victim happily gives it. Anything to stop them disappearing again.”

End stage
“On some level, I’d realised it wasn’t right long before my sons intervened,” says Elizabeth, “but the brain is weird.

I almost convinced myself that it was going to be OK as that was easier than admitting the enormity of it, the money I’d lost.” Her son found some of the paperwork in her bedroom and called his brothers.

“It was a huge shock to them, but they couldn’t have been more supportive,” she says. “They made me see the truth, and they said, ‘All we care about is you.’”

Although Elizabeth wasn’t able to get any answers from “Sam” by confronting him (by this point he was supposedly in a coma), in Carter’s experience, the end stage of a romance scam can be truly chilling.

The mask slips. “They don’t have to be nice any more,” she says.
“Just like in an abusive relationship, when the abuser realises they are losing control, the threats can really escalate to ‘Now you’re going to suffer’.

They’ll message saying, ‘I’ve got 15 of your naked pictures and four of your videos and I’m sharing them with everyone you know unless you send money,’ or ‘I’ve got your home address.

Follow my instructions or I’ll burn your house down.’”
In the immediate aftermath, these possibilities terrified Elizabeth. “As well as feeling devastated and ashamed, I was a nervous wreck,” she says.

“I saw a man sitting in his car outside my house and convinced myself he was one of the scammers. My son had to get a baseball bat while we spied on him through the window.

He finally drove off, completely oblivious. The fact that somewhere someone has those pictures will haunt me for ever.”

Elizabeth reported it to the police, who told her that this was most likely the work of a criminal gang in another country, and the chance of a prosecution and conviction was very low.

Her monthly Victim Support meetings with other victims of romance fraud have been a lifeline, she says.

“Every time you think you’ve heard it all, someone comes with a story that shocks you all over again,” she says.

She did manage to get a large sum of the money refunded by her bank, though not all of it. “As for my own recovery, I’m right at the beginning,” she says.

“I still ruminate on this every single day and don’t know if I’ll ever stop. The scammers are sick. They’ve got no soul. But they are very, very clever.”

How to stay safe
Carter says that all the advice about not giving money to strangers “doesn’t work with romance fraud. To a victim of grooming, this person isn’t a stranger.”

She suggests making sure you keep having conversations about your relationship with friends and family. “Grooming works on the person that’s in it, but not on those on the outside.”

Do some detective work, too. “Independently find two other pieces of information that corroborate what you’ve been told (for example, about where someone is based and what they are doing).

Reverse-image-search all the pictures and videos you’re sent, and the prose as well. You can cut and paste the messages. Find the person online. If you can’t, they aren’t real. Everyone has a trace.”

Finally, remember that if you are being told to lie to your bank, “or being made to feel that your bank is against you, that is a red flag.

The point when you are contacting your bank to transfer money is when you’re in arm’s reach of help, the last port of call before you’re rescued. Tell the bank the truth.”

Victims are encouraged to report to Action Fraud (0300 123 2040), the national reporting centre for fraud and cybercrime. Or get confidential help from Victim Support (08 08 16 89 111)

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22