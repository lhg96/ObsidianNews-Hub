---
title: "Carnival season in Germany and Armistice Day services: photos of the day – Tuesday"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 22:59
url: https://www.theguardian.com/news/gallery/2025/nov/11/carnival-season-germany-armistice-day-photos-of-the-day-tuesday
type: news-article
tags:
  - 뉴스
  - The Guardian
  - carnival
  - season
  - germany
  - armistice
  - services
  - photos
  - tuesday
  - guardian
---

# Carnival season in Germany and Armistice Day services: photos of the day – Tuesday

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 22:59 |
| **원문링크** | [바로가기](https://www.theguardian.com/news/gallery/2025/nov/11/carnival-season-germany-armistice-day-photos-of-the-day-tuesday) |

## 📝 요약
> <p>The Guardian’s picture editors select photographs from around the world</p> <a href="https://www.theguardian.com/news/gallery/2025/nov/11/carnival-season-germany-armistice-day-photos-of-the-day-tuesday">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `carnival` | `season` | `germany`

**태그**: #carnival #season #germany #armistice #services #photos

## 📰 본문

Carnival season in Germany and Armistice Day services: photos of the day – Tuesday
The Guardian’s picture editors select photographs from around the world
Costumed revellers celebrate in the central Heumarkt in Cologne as tens of thousands parade through the streets, officially opening the carnival season. Photograph: Martin Meissner/AP

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22