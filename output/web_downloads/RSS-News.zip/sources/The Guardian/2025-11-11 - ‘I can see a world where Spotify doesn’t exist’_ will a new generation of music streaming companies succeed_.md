---
title: "‘I can see a world where Spotify doesn’t exist’: will a new generation of music streaming companies succeed?"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 20:20
url: https://www.theguardian.com/music/2025/nov/11/spotify-music-streaming-companies
type: news-article
tags:
  - 뉴스
  - The Guardian
  - spotify
  - says
  - music
  - more
  - cantilever
  - skates
  - artists
  - there
authors: Daniel Dylan Wray
---

# ‘I can see a world where Spotify doesn’t exist’: will a new generation of music streaming companies succeed?

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 20:20 |
| **저자** | Daniel Dylan Wray |
| **원문링크** | [바로가기](https://www.theguardian.com/music/2025/nov/11/spotify-music-streaming-companies) |

## 📝 요약
> <p>Nimble, open-minded outfits such as Nina Protocol, Cantilever and Subvert are looking to bring more money to artists, and a richer experience for listeners</p><p>The noise around Spotify this year has been louder than ever, from <a href="https://www.theguardian.com/books/2025/mar/05/mood-machine-by-liz-pelly-review-a-savage-indictment-of-spotify">Liz Pelly’s book Mood Machine</a> – a biting indictment of the company and its alleged practices, described as “error-riddled theories” by Spotify itself – to a slew of indie artists leaving the platform due to political and ethical reasons. There was even a recent music forum in California called <a href="https://www.theguardian.com/technology/2025/oct/12/spotify-boycott-artists">Death to Spotify</a>.</p><p>So the timing is fortuitous for a growing number of independent streaming and music community platforms, such as Nina Protocol, Coda, Subvert, Lissen, Vocana, and just last week a new one launched in the UK: Cantilever. “More people are definitely looking for alternatives,” says Nina Protocol’s chief executive Mike Pollard. “We strongly believe the future of music is independent.”</p> <a href="https://www.theguardian.com/music/2025/nov/11/spotify-music-streaming-companies">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `spotify` | `says` | `music`

**태그**: #spotify #says #music #more #cantilever #skates

## 📰 본문

The noise around Spotify this year has been louder than ever, from Liz Pelly’s book Mood Machine – a biting indictment of the company and its alleged practices, described as “error-riddled theories” by Spotify itself – to a slew of indie artists leaving the platform due to political and ethical reasons.

There was even a recent music forum in California called Death to Spotify.
So the timing is fortuitous for a growing number of independent streaming and music community platforms, such as Nina Protocol, Coda, Subvert, Lissen, Vocana, and just last week a new one launched in the UK: Cantilever.

“More people are definitely looking for alternatives,” says Nina Protocol’s chief executive Mike Pollard. “We strongly believe the future of music is independent.”

Each of the new platforms have unique identities.
Nina Protocol uses an open public network, where artists set their terms and keep 100% of any revenue from downloads; the collectively owned Subvert is intended to be an alternative to Bandcamp, where music files are bought and sold.

Cantilever takes inspiration from curated film streaming platforms such as Mubi, offering a limited and rotating number of albums at a time (currently 10, but up to 30).

What unites them is curation, a sense of community and an artist-friendly, anti-corporate model. “We think a lot about the dignity of releasing music,” says Pollard.

“I don’t think these algorithm-driven reasons for why something’s getting played are very dignified: are you just something that sounds like something they already like?

An artist may say, ‘one of my songs did well on Spotify because it was put in the most popular sleep playlist’. But maybe the 500,000 people who listened to that track weren’t even awake!

And how many of those people know your name, care about you or would buy a ticket to a show?”
View image in fullscreen Cantilever founder Aaron Skates. Photograph: Courtesy: Aaron Skates
Many of these new services also have written articles and editorial, intending to offer contextual deep dives for a more focused listening experience.

“It’s like a music magazine you can listen to,” says Cantilever’s Aaron Skates, an ex-record label worker and music writer who has launched the streaming platform.

Skates has managed to pull in an impressive list of independent labels to work with too, such as Warp, Ninja Tune, Domino and Beggars Group labels such as Rough Trade, 4AD and Matador.

By having a smaller roster of artists, it means they receive more money. “The pool is far less diluted,” Skates says.

“We’re paying out a maximum of 30 artists for all subscriber revenue, versus the 100m tracks on Spotify.

Also, we pay on a user-centric basis, so that means your fee will only ever go towards the music that you actually listen to.” Skates gives me an example: if Cantilever was to get 10,000 subscribers at £4.99 a month, that would result in albums on the service receiving £2,000-3,000 each, which he says is “roughly the equivalent of a million Spotify streams”.

Spotify says in a company response that it “welcomes and celebrates choice and new perspectives,” but claims: “The narrative that the current system is failing artists is not supported by the facts; more artists are earning more than ever.

Rather than just re-dividing the current pie” – through models like Cantilever’s user-centric one – “Spotify is focused on growing it for everyone, increasing the total royalties paid out year after year.”

So, is all this new activity rooted in a revolt against the big companies? “I’m wary about saying that it is anti-Spotify,” says Simon Wheeler, director of commercial strategy at Beggars Group.

“Perhaps more a disillusionment with the complete commoditisation of music.
There’s always a swathe of new entrants to the market, but there’s more coming up that are talking about trying to provide an alternative. The tone of that conversation has changed.”

Wheeler does not view these startups as major competition, though. “Spotify, Apple Music, Amazon, none of them are going anywhere anytime soon,” he says.

“So it’s more like: let’s try and bring something in which is offering something a bit different.” Skates echoes this: “Cantilever is not in any way competitive towards current major DSPs [digital service providers],” he says.

“It’s a totally different thing. I don’t expect anybody to cancel their subscription and just have this – it’s an additional thing that tries to give additional value that wasn’t there before.”

View image in fullscreen A view of Nina Protocol. Photograph: Nina
Pollard, on the other hand, “can see a world where Spotify doesn’t exist in the future,” he says.
“Where people realise the options given to them aren’t the ones that best serve them.” Although the numbers aren’t quite showing this yet, with Spotify revealing an additional five million paying subscribers in this year’s third quarter report, that’s not to say the interest in alternatives isn’t rising.

The five-person team at Nina Protocol is struggling to keep up with inbound interest and Skates says despite only launching a week ago, the interest and listener numbers for Cantilever have “surpassed my expectations”.

Pollard suggests there is a wider cultural sea change beginning to take place, one that leaves him hopeful of a brighter future for music culture in the streaming era.

“There’s a growing awareness of how slop-filled everything is getting,” he says.
“People are wanting a little more control of what they consume.” He gives the example of users leaving X, formerly Twitter: “They realised, ‘Shit, I don’t need to be here any more.’ Then you understand what it feels like to be more intentional about your choices, instead of just being on everything that you’re told you need to be on to exist.

I think people are waking up.”

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22