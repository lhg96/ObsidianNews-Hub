---
title: "‘Too far? I don’t think we’ve gone far enough!’ The founder of Peta on gruesome stunts and her bloody fight for animal rights"
source: The Guardian
date: 2025-11-09
datetime: 2025-11-09 21:00
url: https://www.theguardian.com/us-news/2025/nov/09/ingrid-newkirk-peta-interview-animal-rights
type: news-article
tags:
  - 뉴스
  - The Guardian
  - fur
  - peta
  - newkirk
  - animal
  - says
  - fashion
  - about
  - which
authors: Morwenna Ferrier
---

# ‘Too far? I don’t think we’ve gone far enough!’ The founder of Peta on gruesome stunts and her bloody fight for animal rights

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-09 21:00 |
| **저자** | Morwenna Ferrier |
| **원문링크** | [바로가기](https://www.theguardian.com/us-news/2025/nov/09/ingrid-newkirk-peta-interview-animal-rights) |

## 📝 요약
> <p>After 45 years as chief fake blood thrower, Ingrid Newkirk is still waging war on everything from leather to cashmere. Is she still relevant?</p><p>Ingrid Newkirk was 54 when she thought she was going to die in a plane crash. It was late summer and the founder<strong> </strong>of <a href="https://www.peta.org.uk/">People for the Ethical Treatment of Animals</a> (Peta) was flying from Minneapolis in the US to the company HQ in Norfolk, Virginia when her plane encountered strong wind shear. The pilot attempted an emergency landing, but failed; back up they went.</p><p>On the third attempt, with “a teaspoon of fuel” in the tank, he finally got the plane down safely. During those moments, Newkirk, now 76, scribbled a will on a napkin. She has tweaked it over the years, but it still reads like a horror movie prop list: her liver is to be sent to France to be made into foie gras, her skin to Hermès to create a handbag and her lips to whichever US president is in power, to shame them for granting a “patronising” pardon to a turkey each Thanksgiving. As wills go, it’s straight out of the <a href="https://www.theguardian.com/us-news/peta">Peta</a> playbook: an audacious stunt of the kind that has made them the world’s most well-known, successful and in some quarters reviled animal rights organisation. “I know I’ll never be made a dame,” Newkirk says, laughing. “I’m too controversial.”</p> <a href="https://www.theguardian.com/us-news/2025/nov/09/ingrid-newkirk-peta-interview-animal-rights">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `fur` | `peta` | `newkirk`

**태그**: #fur #peta #newkirk #animal #says #fashion

## 📰 본문

Ingrid Newkirk was 54 when she thought she was going to die in a plane crash.
It was late summer and the founder of People for the Ethical Treatment of Animals (Peta) was flying from Minneapolis in the US to the company HQ in Norfolk, Virginia when her plane encountered strong wind shear.

The pilot attempted an emergency landing, but failed; back up they went.
On the third attempt, with “a teaspoon of fuel” in the tank, he finally got the plane down safely. During those moments, Newkirk, now 76, scribbled a will on a napkin.

She has tweaked it over the years, but it still reads like a horror movie prop list: her liver is to be sent to France to be made into foie gras, her skin to Hermès to create a handbag and her lips to whichever US president is in power, to shame them for granting a “patronising” pardon to a turkey each Thanksgiving.

As wills go, it’s straight out of the Peta playbook: an audacious stunt of the kind that has made them the world’s most well-known, successful and in some quarters reviled animal rights organisation.

“I know I’ll never be made a dame,” Newkirk says, laughing. “I’m too controversial.”
Forty-five years into Peta’s existence, she can claim to have won many battles.
Animal testing is marginally down, with multinational companies having to at least pay lip service to ideas around animal cruelty and environmentalism.

And according to YouGov, more than 25 million people worldwide have at least dipped a toe into veganism.

Peta has certainly played some part in this, with its celebrity endorsements and theatrical stunts now par for the course in mainstream activism.

If they didn’t invent direct action, they normalised it.
But when it comes to fashion, in an era defined by waste in which our wardrobes are directly linked to global economic, humanitarian and climate crises, do we simply have more pressing concerns than whether or not to wear cashmere?

In short: is Peta still relevant?
We meet in the Peta headquarters, a relatively humdrum and leather-free office in a north London office block near the Regent’s canal.

Newkirk looks a decade younger than she is, a little like Princess Diana but with a blond Chelsea bob.

Her hair used to be longer but she recently cut off a few inches to sew into a scarf she plans to send to her favourite target, Condé Nast head honcho Anna Wintour.

Peta has plagued the fashion icon for more than 30 years in protest at US Vogue’s historical policy of featuring animal skin and fur.

The brown scarf, made entirely of human hair, is boxed up and on the table next to a plate of vegan croissants, Newkirk’s hair woven into the fringes.

“It’s actually a peace offering,” she says, laughing. In using her own hair, she hopes to “teach Anna about consent”.

Newkirk is in town to deliver the scarf (Wintour is here for London fashion week) but has found time for a grisly stunt in which she’ll dress up as a bloodied goat at one venue (Peta have industry moles tipping them off on show locations and schedules).

The target is the cruelty of cashmere farming in Mongolia – one of Peta’s betes noires, along with wool and shearling. “It’s about tactics, and tactics I think work,” she says.

But, frankly, she could be talking about any number of the antics that have studded her 45-year-long career.

View image in fullscreen Newkirk at London fashion week in September, protesting about the treatment of goats during cashmere production. Photograph: SOPA Images/LightRocket/Getty Images

Take the Victoria’s Secret show in 2002 when a protester got past security to storm the catwalk holding a “Gisele: Fur Scum” sign aimed at the supermodel, or in 2005, when Newkirk lay naked in a coffin in New York’s Times Square to protest at fur in Macy’s.

But it was the “I’d rather go naked than wear fur” campaign in the 90s, which saw celebrities such as Kim Basinger and Christy Turlington make good on that promise, that put Peta on the map.

Newkirk has lost count of the amount of tofu pies and fake blood thrown at notables since then.
But if Peta excel in manufacturing outrage for publicity, they overstep the mark, too.
In 2003, they compared the treatment of animals to the Holocaust, and in 2011 referenced the slave trade when campaigning to free orcas from an amusement park.

“Slavery is not something we can only apply to one species – our own,” Newkirk insists.
“To capture, deprive of freedom of movement and association, and to extract forced labour from the orcas fit the definition of slavery.”

A “holocaust on your plate” exhibit they displayed was condemned as “graphic” by the Greater London Authority and “shocking and outrageous” by Manchester City Council – and was ultimately banned in the UK.

Did she regret the comparison? “It was powerful, but some people, as people do, took it as an attack on them, which it certainly was not.”

As you know, the press likes the gawky, gimmicky, sexy bits, so that’s what we’re most associated with

Newkirk is broadly unapologetic about Peta’s past stunts. “You might say they are shocking, but it’s just the shocking facts,” she says, plainly. Does she regret any of them?

“I have no regrets.” Does she think they ever went too far?
“I don’t think we went far enough.” In 2015 Peta sued the photographer behind a viral series of “monkey selfies”, saying the macaque should hold the copyright and get the proceeds of any sales.

The case settled; the publicity went around the world.
In the end, whether it’s zoos or fur coats, it all comes back to her central idea that animals and humans are one and the same, and when it comes to animal rights, she is absolute.

“We don’t want to put a tofu pie in someone’s face. We don’t want to take red paint on to a catwalk. I don’t enjoy it, I’d prefer it wasn’t like this, but I’m just showing the facts,” she says.

“We lose members sometimes. They say we alienate. But you try talking to the press with a list of hard facts on white paper. It’s dull. It’s not news.

Chain yourself to the front of a Canada Goose store and gotcha! You get coverage.”
Their approach seems to have mellowed over the years; one of their softer tactics is buying shares in the companies they “want to change”, to lobby from the inside.

They hold shares in conglomerates such as Kering, Prada and LVMH, which gives them a seat at the boardroom table and access to the CEOs.

Peta takes credit for H&M no longer using new down and feathers, and Kering banning fur across their brands in 2021.

Mention of Peta’s name is enough to provoke ire and terror in companies that use animal products, but they aren’t exactly beloved in the world of activism either.

One environmental campaigner told the Guardian that Peta “have a reputation for riding roughshod over anyone else’s work, sensibilities and strategies”.

Newkirk insists they’ve always taken a more measured approach, “talking, writing and litigating” to make their case, “but as you know, the press likes the gawky, gimmicky, sexy bits, so that’s what we’re most associated with”.

Newkirk was born in Surrey in 1949. Her father was an engineer and the family moved around, going to India when she was seven, where she went to boarding school, though they also spent time in Orkney.

There, her bedroom was full of feather headdresses and statues made of seal fur, souvenirs brought home by her father who often worked overseas. Going to the circus was a family day out.

Her uncle owned a dairy farm. They all wore head-to-toe wool. “I loved animals. Let’s just say it took a while for the lights to come on.”

Back then, animal protesting didn’t extend beyond shouting about foxhunting. She’s had a few Damascene moments, but the one that sticks in her mind took place in the early 70s.

Newly married to an American (they have since divorced) and living in rural Maryland, Newkirk was training to be a stockbroker.

One day she discovered a litter of kittens abandoned by a neighbour, and took them to a shelter. The next day, she went back to check on them, only to be told they had been put down.

“I was stunned, utterly horrified. It changed everything.”
She begged the shelter’s manager for a job.
When he agreed, she began this second career, which involved short stints as an animal inspector, then deputy sheriff focusing on animal cruelty cases, then a cruelty law enforcement officer, before becoming the first female master at a dog pound.

Through her work, she met fellow animal rights activist Alex Pacheco and in 1980 they founded Peta (he left the company in 1999), though their first fashion stunt – a naked protest on the Oscar de la Renta catwalk – didn’t happen for another decade.

When I imply her career may have been complicated by the fact that she’s a woman, she pauses briefly, then balks. “Have I been treated differently?

I don’t like the idea that people might have treated me differently,” she says.
“But it’s true that people love to ask how I justify working for animal rights given what else is going on in the world and they would never ask a Premier League footballer how they justify playing football.”

For a period in the 90s and 00s, Peta was sustained by celebrities who flocked to the cause.
Alicia Silverstone, Alec Baldwin, Drew Barrymore, Anjelica Huston and various top-earning supermodels have all backed Peta.

Some are approached by the organisation; others, such as Pamela Anderson – Peta’s most famous advocate – come to them.

Newkirk recalls receiving a letter from Anderson handwritten on lilac stationery saying she was on a show called Baywatch, but all the press wanted to talk about was her “boobs and boyfriends”; she wanted to use her position to talk about animals.

“Inside that big chest beats a very big heart,” Newkirk says.
Anderson and the naked campaigns made Peta a household name, but not everyone felt the cause needed nudity to make an impact. Newkirk can’t understand the backlash.

“What is so shocking about a naked body? I think it shows strength,” she says. “That is feminism, it’s consensual, it’s Lady Godiva!

The Peta women have the right to use their bodies however they wish – we don’t live in Afghanistan. How dare men or other women dictate how much they must cover up.” This is why she admires Anderson.

“I’m not a beauty, I don’t have any assets. If I had them, would it have made a difference? Who knows. But she has worked it so well,” she laughs.

View image in fullscreen Newkirk protesting outside a KFC in Mumbai in 2014. Photograph: Punit Paranjpe/AFP/Getty Images

While other activists are suspicious of them, those methods have enjoyed a certain amount of success.

Peta now has more than 10 million members and supporters, and more than 800 staff worldwide, according to Newkirk. The people who work there tend to be vegan.

If Peta isn’t terribly popular within fashion and activism, Newkirk must be at work: around a third of Peta’s staff have been there for more than a decade.

Their targets are divided between factory farming, animal research, animal entertainment (such as circuses) and using animal products in fashion and beauty.

It’s the last one that carries the most everyday tension, and lands the headlines. “I treat them all as ‘lifestyle’ – food, fashion, it’s all related,” Newkirk says.

“If I had to pick a cause that matters most, I couldn’t.”
These days, she has largely swapped the stunts for strategising and emails – she receives around a thousand a day – mostly on the road between Washington, Hamburg, India and Norfolk, Virginia.

She works seven days a week, leaving little time to cook – breakfast is soy sausages and bean burritos reheated in the microwave.

She has a long-term partner; to the disappointment of her mother, she was sterilised in her 20s – “I love children but there are already surplus in the world.”

skip past newsletter promotion Sign up to Inside Saturday Free weekly newsletter The only way to get a look behind the scenes of the Saturday magazine.

Sign up to get the inside story from our top writers as well as all the must-read articles and columns, delivered to your inbox every weekend.

Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion
Curiously, she unwinds by watching Formula One. Does she worry about the environmental impact?
“It cannot hold a candle to meat, dairy and egg production, which is a bigger contributor to the climate crisis than all forms of transportation put together.”

Peta’s aim – to change how the world sees, treats and protects animals – has remained largely unchanged over 45 years, but in terms of animal skins, they’ve made huge progress.

“We don’t take full credit for this,” Newkirk says. “I mean, we work our socks off, and a lot of it is attributable to us. But there are lots of companies doing great work, too.

Stella McCartney, for example. I knew her mother, and Stella didn’t fall far from the tree. She has always known the use of animals is wrong.”

McCartney, who whips up impressively vegan clothes using faux leather, is one of the industry’s most vocal animal and cruelty-free advocates.

“My mum and Ingrid were friends – they shared a fearless belief that kindness can change the world,” she tells me in an email.

“They’ve never been afraid to call the industry out … That bravery has provoked conversations that needed to happen, often with an edge and even humour.”

One of the people who has borne the brunt of this “humour” is Wintour.
Newkirk has lost track of the number of Peta stunts levelled at the former Vogue editor, including writing to the IRS “to see if she was declaring tax on free fur gifts”; throwing a dead racoon into her soup at the Four Seasons in New York; occupying, then graffitti-ing Vogue’s HQ (Wintour locked herself in her office and the stunt landed Newkirk in a cell for a night); and offering her a brain scan to check if her motor neurons were underdeveloped.

Did Wintour ever reply? “She did not.” Still, the big fur ads stopped appearing in the magazine and its publisher, Condé Nast, says it will no longer feature fur in its titles.

Thanks in large part to our relentless campaigning, most of today’s fashion-minded crowd wouldn’t be caught dead in fur

Was that Peta’s doing? “It’s certainly a signal that fashion is finally shifting,” Newkirk says.
“Some people resist change more than others but, thanks in large part to our relentless campaigning, most of today’s fashion-minded crowd wouldn’t be caught dead in fur.”

She’s half right. On paper, the fur industry has been dwindling for years. Calvin Klein was among the first big fashion houses to ban it in 1994. Then came Ralph Lauren a decade later.

It wasn’t until 2017 when Gucci stopped using fur that things sped up. Burberry, Celine, Patou, Prada, Versace and Marc Jacobs followed.

Global fur production fell 85% in the last decade, according to the Fur Free Alliance.
This year is the first that London fashion week has banned all animal skins, and though Paris and Milan have yet to follow suit – among the fashion houses holding firm is Italian brand Fendi, founded a hundred years ago as a fur and leather shop – it’s unusual to see real fur on the catwalk.

Instead there has been a slow creep in very realistic fake fur in fashion shows – and with that a renewed demand for vintage fur, which is usually much cheaper.

This is good news, says Tea Baines, marketing manager at cult secondhand shop Beyond Retro, because it is “opposed to modern fur production”, while also noting that it is a more sustainable alternative than simply “sending it to landfill, where it would add to textile waste”.

The hope “is to ease the pressure on both modern fur and mass-produced faux-fur production”.
Newkirk is horrified by the idea that real fur is on trend again, even if it is vintage. “If it comes back, it is a failing on our part.

But I also believe it’s a trend, so not lasting; it’s for effect, and it’s flamboyant rubbish.”
She’s right that trends come and go. But for the past decade, fashion has become as preoccupied with the environment as animal rights.

Faux fur is often made from plastic derivatives, which means real, secondhand fur is seen as better for the environment.

Just ask Rihanna, who wore old Galliano mink out and about in New York last Christmas without a tofu pie in sight.

Newkirk shakes her head.
“If you care about health, then eating meat clogs your arteries – and if you care about the climate, you can’t possibly continue to eat animals or consume dairy,” she says, citing methane production and over-farming as the real issue for environmentalists.

“People who claim to be one but who eat meat and wear animals just need to look at the amount of energy used in angora production.”

One issue could be affordability: not everyone can afford an ethical lifestyle. “But the cost is coming down,” she says.

Even so, isn’t real animal skin better for the environment than its faux counterparts? “Look.
If the argument is that plastic isn’t biodegradable, then neither is leather – it doesn’t break down because of what it’s been treated with, so that’s neither here nor there,” she says.

“It’s fashion, things get replaced.”
In person Newkirk is warm and charming, with a wry sense of humour, until you query her defining worldview – that animals have the same rights as humans – at which point the clouds darken, those sharp blue eyes narrow and the proselytising begins.

“Even if it’s sustainable, whatever that means, you wouldn’t make something in human skin just because that person was skinned in their sleep at the time, would you?”

It’s perhaps a surprise that Newkirk even considers these questions. Yet among her proclamations there is pragmatism, and even logic.

If you’re wearing vintage fur, you are arguably perpetuating the idea of fur, she says, which is why Peta has a “fur kitchen”. A what? “People can donate old fur coats to the homeless.

Anjelica Huston gave us some, and we’re trying to get Yoko Ono to give up her refrigerated room of fur.” Peta are happy for fur to be used in this way because it’s not as a fashion statement.

They also donate fur for school presentations about animals. The best solution for us all is buying secondhand clothing, she says, pointing at her chintz jacket, which came from a charity shop.

A few days after we meet, images of Newkirk dressed up as a goat appear online.
She’s wearing a fake fur coat doused in fake blood, lying down on the Strand in London and pretending to have hair violently combed from her body while miming along to the actual sound of screaming goats recorded during a Peta investigation.

By the usual standards of the group, the stunt falls slightly flat, drawing a small crowd and meagre press coverage.

The same could be said for a semi-naked protest in Pamplona over the famous bull run in July, or the man who lay down outside a Gucci store in Kuala Lumpur in January dressed as a python in protest at their use of snakeskin, neither of which made the news as once they would have.

In those moments Peta can feel a relic of a bygone era. Still, it would be impossible to deny the impact Peta – and Newkirk’s singular vision – have had on animal rights, and will continue to have.

Her impulse to try to convert everyone she meets to veganism will never leave her, though she admits it’s been a while since she’s had to accost anyone for wearing mink on the street.

Is that because the war on fur is largely won? “I’d like to think so,” she says.

## 📅 관련 노트
- 일간 정리: [[2025-11-09]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22