---
title: "I’m a food writer with a binge-eating disorder, and I’m learning to reject shame"
source: The Guardian
date: 2025-11-08
datetime: 2025-11-08 08:00
url: https://www.theguardian.com/lifeandstyle/2025/nov/08/food-writer-with-binge-eating-disorder
type: news-article
tags:
  - 뉴스
  - The Guardian
  - food
  - binge
  - eating
  - more
  - about
  - nothing
  - disorder
  - what
---

# I’m a food writer with a binge-eating disorder, and I’m learning to reject shame

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-08 08:00 |
| **원문링크** | [바로가기](https://www.theguardian.com/lifeandstyle/2025/nov/08/food-writer-with-binge-eating-disorder) |

## 📝 요약
> <p>My job and my disordered eating have long fed each other. Talking publicly about my experience helps lift the veil of secrecy surrounding it</p><p>Nothing in my life sparks greater joy and deeper shame than food. Publicly, I live and love to eat. As a food writer my livelihood depends on it. But privately, I live with a binge-eating disorder, and it can feel like what I’m devouring is actually devouring me.</p><p>My family is Italian, and their love language is food, so food is also the portal to all my memories, good and bad. Nonna’s lasagne at Easter, her zeppole at Christmas, were the best of times. The worst: foil trays piled with fried food at funerals, the liquorice allsorts I ate – and now hate – after my infant brother choked and paramedics rushed him to hospital. Emotional eating has always been so normal for me.</p> <a href="https://www.theguardian.com/lifeandstyle/2025/nov/08/food-writer-with-binge-eating-disorder">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `food` | `binge` | `eating`

**태그**: #food #binge #eating #more #about #nothing

## 📰 본문

Nothing in my life sparks greater joy and deeper shame than food. Publicly, I live and love to eat. As a food writer my livelihood depends on it.

But privately, I live with a binge-eating disorder, and it can feel like what I’m devouring is actually devouring me.

My family is Italian, and their love language is food, so food is also the portal to all my memories, good and bad. Nonna’s lasagne at Easter, her zeppole at Christmas, were the best of times.

The worst: foil trays piled with fried food at funerals, the liquorice allsorts I ate – and now hate – after my infant brother choked and paramedics rushed him to hospital.

Emotional eating has always been so normal for me.
As a kid, I got a thrill out of smuggling chocolates into the bathroom, locking the door, downing them in quick succession then hiding the wrappers.

A binge is like a runaway train: fast, uncontrollable, not stopping for anything
In my last year of school I experienced drastic weight gain, then equally drastic weight loss soon after – by depriving myself of calories and exercising to exhaustion. I got caught in a vicious cycle.

That level of restriction was unmaintainable, but every day thereafter I tried. Most days I failed. The instant something I deemed “unhealthy” hit my lips, all bets were off.

At first, gorging myself on all manner of deliciousness I could find felt like a pressure valve, a euphoric guilty pleasure that onlookers saw purely as a feast.

But as it became a regular occurrence, increasingly in private, the pleasure started to fade. With each binge – yet another perceived failure – the self-soothing morphed into self-loathing.

A binge is like a runaway train: fast, uncontrollable, not stopping for anything.
There’s also nothing indulgent about it, going to bed as your stomach stretches achingly taut. It’s insufferable. And going cold turkey isn’t an option.

A decade ago, my food “noise” – an insatiable, inescapable inner monologue – was turned up to full blast when I started writing about food while studying journalism.

In many ways it made sense, converting passion to profession. I already had food on my mind constantly. Now my career was crystallising around it.

It’s Australia’s most common eating disorder, but nothing has isolated me more
I panic-emailed the Butterfly Foundation, which specialises in eating disorders.
That led to me being diagnosed and treated for a few years pre-Covid, but keeping a journal of everything I ate between sessions just felt like my fixation taking a different form.

Through Melbourne’s lockdowns, I worked from home as a full-time editor in food media, my job and my disordered eating feeding each other. By day, I covered restaurants pivoting to takeaway.

By night, I would binge on that very same takeaway.
Coming out of lockdown, socialising was tough and industry dinners were triggering.
I’d be so in my head about overeating in front of colleagues and peers that I’d try to slow my racing thoughts with alcohol.

One night, arriving home inhibition-less, I consumed whatever I could find, joylessly and out of sheer desperation. I vomited violently, bursting blood vessels in my eyes, turning the whites red.

Barely anyone knows this, because much of what makes binge eating so brutal isn’t just the disorder itself. It’s the veil of shameful secrecy that surrounds it.

The more you binge, the more alone you feel, and the more alone you feel, the more you binge. It’s Australia’s most common eating disorder, but nothing has isolated me more.

My most successful recovery so far came when I quit my job, taking three circuit-breaking months off to build more balanced habits.

I focused on eating three meals a day with two snacks, as my clinician had suggested years prior; it seems simple, but it was a gamechanger in binge prevention.

With what felt like a clean slate, I rediscovered my love for writing about food, as a freelancer.
Binge eating now has me in far less of a chokehold than it once did. But there are still days when I’d give anything to quiet the food noise.

Reconciling my career with my condition, I’m learning not to be ashamed by the obsession, and the endless internal chatter, but to harness it, to understand it.

Because after half a lifetime of waging war on myself – mind and body – if there’s one thing I know about shame, it’s that it thrives in the shadows. So, what if I let the light in?

## 📅 관련 노트
- 일간 정리: [[2025-11-08]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22