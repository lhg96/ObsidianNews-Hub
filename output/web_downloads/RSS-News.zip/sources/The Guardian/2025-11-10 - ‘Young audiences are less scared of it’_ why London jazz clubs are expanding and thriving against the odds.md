---
title: "‘Young audiences are less scared of it’: why London jazz clubs are expanding and thriving against the odds"
source: The Guardian
date: 2025-11-10
datetime: 2025-11-10 23:43
url: https://www.theguardian.com/music/2025/nov/10/london-jazz-clubs-expanding-thriving-against-the-odds-jazz-cafe-ronnie-scotts-blue-note
type: news-article
tags:
  - 뉴스
  - The Guardian
  - jazz
  - music
  - venues
  - london
  - clubs
  - ronnie
  - says
  - their
---

# ‘Young audiences are less scared of it’: why London jazz clubs are expanding and thriving against the odds

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-10 23:43 |
| **원문링크** | [바로가기](https://www.theguardian.com/music/2025/nov/10/london-jazz-clubs-expanding-thriving-against-the-odds-jazz-cafe-ronnie-scotts-blue-note) |

## 📝 요약
> <p>As the Jazz Cafe and Ronnie Scott’s expand, and Blue Note eyes its arrival, proprietors say there’s an energy in the scene – but financial pressures remain</p><p>As small gig venues around the country nervously eye their futures amid rising utility prices and a cost of living crisis, one corner of the live music scene seems to be thriving: London’s jazz clubs.</p><p><a href="https://thejazzcafe.com/">The Jazz Cafe</a> is extending its Camden venue and opening an east London location, <a href="https://www.ronniescotts.co.uk/">Ronnie Scott’s</a> is being refurbished, and New York’s iconic <a href="https://www.bluenotejazz.com/">Blue Note club</a>, which has already spread to Japan, Brazil, Italy and China, will open its first London venue next year. And while financial pressures remain, a host of other, smaller venues are bringing in vibrant new audiences.</p> <a href="https://www.theguardian.com/music/2025/nov/10/london-jazz-clubs-expanding-thriving-against-the-odds-jazz-cafe-ronnie-scotts-blue-note">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `jazz` | `music` | `venues`

**태그**: #jazz #music #venues #london #clubs #ronnie

## 📰 본문

As small gig venues around the country nervously eye their futures amid rising utility prices and a cost of living crisis, one corner of the live music scene seems to be thriving: London’s jazz clubs.

The Jazz Cafe is extending its Camden venue and opening an east London location, Ronnie Scott’s is being refurbished, and New York’s iconic Blue Note club, which has already spread to Japan, Brazil, Italy and China, will open its first London venue next year.

And while financial pressures remain, a host of other, smaller venues are bringing in vibrant new audiences.

“I’ll have been doing this for 50 years next year and, to be honest, I’ve seen quite a few ‘resurgences’,” says Steve Rubie, owner of the 606 Club in Chelsea.

But, he adds, there’s something genuinely different today. “Younger audiences are less scared of jazz. It’s all just music to them.”

That open-mindedness and freedom has been powering London’s globally famous jazz scene over the last decade, as young musicians who were learning their craft at Tomorrow’s Warriors and the city’s music schools also cut their teeth in clubs, from late-night jams at Ronnie Scott’s to the improvised jazz parties of Steam Down events – all of it attracting an equally cosmopolitan audience.

Those artists included Ezra Collective, who have won the Mercury prize and played Wembley Arena, and that kind of success is rooted in jazz clubs, “the heartbeat of the jazz scene” according to Aisling Doherty, programming coordinator at the EFG London jazz festival, which is back for its 33rd year this week.

A strand of concerts at the festival celebrating the jazz club seeks to “honour the spaces who work day in and day out” to make London’s scene thrive, says Doherty.

View image in fullscreen Performers at Toulouse Lautrec jazz club, Kennington. Photograph: (no credit)

At Ronnie Scott’s, the most famous of these London venues, straight-ahead jazz in the afternoon might attract more traditional listeners than the twenty- and thirtysomethings who would come out for a late show featuring live remixing and broken beat.

But at Toulouse Lautrec in Kennington, the classics of the genre are finding new fans.
“Young people are keen to learn more about the history behind the music,” says manager Nolan Regent, who notes the popularity of their “the music of” series, which explores the work of iconic figures from jazz history.

“I love that they’re listening to older styles of jazz.”
And as jazz audiences grow, so are the city’s clubs.
The Jazz Cafe is extending into a neighbouring building, and in May was granted planning permission to transform an art deco theatre in Stratford into a new outpost.

Ronnie Scott’s has completely renovated its upstairs space into a new small venue, which will open in February; its green room will double as a members’ bar, where performers and audiences can mingle after a gig, complete with a piano for impromptu jams.

Blue Note is coming to Covent Garden in 2026, overcoming fears from police and local residents that its 1am closing time could result in an “uptick in crime” in the area – perpetrated against, rather than by, jazz fans.

But the late licence was granted in May, and the space, in the basement of the St Martin’s Lane Hotel, is now being renovated to accommodate two performance spaces and a kitchen.

While these prominent clubs arrive or expand, grassroots music venues in the UK are “facing a crisis of soaring costs and closures”, according to the government’s cross-party Culture, Media and Sport Committee; research by the Music Venue Trust (MVT) found that nearly half of grassroots venues were running at a loss last year.

View image in fullscreen Ronnie Scott’s new upstairs space, Upstairs at Ronnie’s. Photograph: Ronnie Scott’s

Many are still struggling to recover from the period of closure necessitated by Covid, and London’s jazz clubs are no exception.

Vortex in Dalston turned to crowdfunding in 2020 to remain afloat and, like many venues, relies on volunteers. Kansas Smitty’s on Broadway Market closed during the pandemic and never reopened.

The small basement space was a dynamic setting for the house band’s lively swinging – and the very opposite of social distancing.

But for clarinettist and saxophonist Giacomo Smith, who co-founded the venue in 2015, the decision not to reopen wasn’t purely financial.

“You only have one career – and for me, I want to play,” he says. “I don’t think musicians should start jazz clubs, just like I don’t think chefs should start restaurants. Because they care too much.

At the end of the day, it has to be a business that works.”
The cross-party committee has suggested introducing a ticket levy on arena-level live music events – whether voluntary, and administered by an organisation such as the MVT, or government-run, as has existed in France since the 1980s – to feed money back into grassroots venues that are vital to musicians’ artistic development and their ability to make a living, and where “there’s an electricity … between the musicians and the audience”, says Smith.

In small venues, Rubie adds, “being a member of an audience is as important as being a member of the band. It’s a joint venture.”

At a time of polarisation, there’s renewed value to the intimate, dimly lit rooms where veteran jazz disciples rub shoulders with young, diverse new fans in the name of the music they love.

So what can people do to support local clubs? “Visit them regularly!” says Rubie, adding that it’s also helpful to show venues support on social media.

Regent says that he sees lots of people coming to gigs on their own. “Bring a friend,” he suggests. “Music should bring people together.”

## 📅 관련 노트
- 일간 정리: [[2025-11-10]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22