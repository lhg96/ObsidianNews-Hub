---
title: "‘It’s changed me’: Jeff Goldblum says he has stopped eating meat after working on Wicked"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 21:50
url: https://www.theguardian.com/culture/2025/nov/11/jeff-goldblum-stopped-eating-meat-after-working-on-wicked
type: news-article
tags:
  - 뉴스
  - The Guardian
  - goldblum
  - said
  - animal
  - about
  - newsletter
  - account
  - vegan
  - working
authors: Catherine Shoard
---

# ‘It’s changed me’: Jeff Goldblum says he has stopped eating meat after working on Wicked

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 21:50 |
| **저자** | Catherine Shoard |
| **원문링크** | [바로가기](https://www.theguardian.com/culture/2025/nov/11/jeff-goldblum-stopped-eating-meat-after-working-on-wicked) |

## 📝 요약
> <p>Actor said discussions about animal cruelty with director Jon Chu had led him to join Ariana Grande and Cynthia Erivo in renouncing meat</p><p>The actor Jeff Goldblum has credited working on the Wicked movies with his decision to turn pescatarian.</p><p>Speaking on This Morning, Goldblum, 73, said that he had been affected by the film series’ themes of animal cruelty to such an extent that he stopped eating meat.</p> <a href="https://www.theguardian.com/culture/2025/nov/11/jeff-goldblum-stopped-eating-meat-after-working-on-wicked">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `goldblum` | `said` | `animal`

**태그**: #goldblum #said #animal #about #newsletter #account

## 📰 본문

The actor Jeff Goldblum has credited working on the Wicked movies with his decision to turn pescatarian.

Speaking on This Morning, Goldblum, 73, said that he had been affected by the film series’ themes of animal cruelty to such an extent that he stopped eating meat.

“Working with [director] Jon Chu [is] amazing,” he said. “It’s changed me. You know, after doing this movie, we talked about the animal cruelty, I stopped eating meat and poultry.”

He added: “We need the world to work for everybody on Earth and every creature, too.”
Goldblum plays the Wizard of Oz in the films, the first of which was released last year and earned 10 Oscar nominations, and the second of which is in cinemas on 21 November.

skip past newsletter promotion Sign up to First Thing Free daily newsletter Our US morning briefing breaks down the key stories of the day, telling you what’s happening and why it matters Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion
“It’s uncommon that you get to be doing this over a period of time and get more fertile and juicy and interesting and relevant roles for yourself at this period of time,” he said of the experience.

Wicked: For Good takes place some years after the events of the first film, with Cynthia Erivo’s Elphaba – now known as the Wicked Witch of the West – a fugitive fighting for animal rights, while Ariana Grande’s Galinda is the public figure of Glinda the Good, watched over by Goldblum’s villainous leader.

Both Grande and Erivo have been vegan since 2013. On-set conversions to vegetarianism are not uncommon.

James Cromwell, now a prominent vegan activist, gave up all foods involving animal products on the second day of filming George Miller’s Babe in 1995.

“I broke for lunch before everybody else,” he said. “All the animals I’d worked with that morning were on the table, cut up, fricasseed, roasted and seared. That was when I decided to become a vegan.”

View image in fullscreen Joaquin Phoenix at the 2020 Oscars. Photograph: Étienne Laurent/EPA
A number of actors have credited Woody Harrelson with converting them to veganism – Sadie Sink on the set of The Glass Castle, Thandiwe Newton on Solo: A Star Wars Story and Liam Hemsworth while working on The Hunger Games.

Other prominent vegan or vegetarian actors include Natalie Portman, Jessica Chastain, Brad Pitt, Tobey Maguire and Zendaya.

In 2020, Joaquin Phoenix used his best actor Oscar acceptance speech to campaign for an end to dairy farming.

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22