---
title: "Lipstick, manicures ... and fascism: the ugliness behind the $450bn beauty industry"
source: The Guardian
date: 2025-11-08
datetime: 2025-11-08 02:45
url: https://www.theguardian.com/wellness/2025/nov/07/beauty-industry-arabelle-sicardi-book
type: news-article
tags:
  - 뉴스
  - The Guardian
  - beauty
  - about
  - people
  - your
  - sicardi
  - book
  - industry
  - didn
authors: Estelle Tang
---

# Lipstick, manicures ... and fascism: the ugliness behind the $450bn beauty industry

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-08 02:45 |
| **저자** | Estelle Tang |
| **원문링크** | [바로가기](https://www.theguardian.com/wellness/2025/nov/07/beauty-industry-arabelle-sicardi-book) |

## 📝 요약
> <p>In their new book The House of Beauty, beauty writer Arabelle Sicardi examines the good, the bad and the ugly of the lucrative industry</p><p>The very first sentence of Arabelle Sicardi’s book, The House of Beauty, reads: “When I tell you that beauty is a monster, I need you to know it is my favorite kind.”</p><p>Sicardi, who splits their time between New York City and Los Angeles, has a love/hate relationship with the beauty industry. A writer and consultant working in beauty and tech, their projects include a <a href="https://arabellesicardi.substack.com/">beauty newsletter</a>, a creative collective called <a href="http://perfumedpages.xyz/">Perfumed Pages</a> and a non-profit arts project called the <a href="http://museumofnails.com/">Museum of Nails Foundation</a>. In their new book, they examine the impact of the $450bn beauty industry – the pretty and the very ugly.</p> <a href="https://www.theguardian.com/wellness/2025/nov/07/beauty-industry-arabelle-sicardi-book">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `beauty` | `about` | `people`

**태그**: #beauty #about #people #your #sicardi #book

## 📰 본문

The very first sentence of Arabelle Sicardi’s book, The House of Beauty, reads: “When I tell you that beauty is a monster, I need you to know it is my favorite kind.”

Sicardi, who splits their time between New York City and Los Angeles, has a love/hate relationship with the beauty industry.

A writer and consultant working in beauty and tech, their projects include a beauty newsletter, a creative collective called Perfumed Pages and a non-profit arts project called the Museum of Nails Foundation.

In their new book, they examine the impact of the $450bn beauty industry – the pretty and the very ugly.

Sicardi has written about beauty as “a terrorizing force” for their whole career, including a stint as a beauty editor at BuzzFeed, which proved a spiky learning experience.

“I wrote a story critical of an advertising campaign and then got flak for it,” they recall.
“I decided to leave because I didn’t want to deal with the politics and the insincerity of being told I can do something, but then having my work deleted.

That type of situation still happens very regularly to writers for publications to this day,” they said.

In an era of unrealistic beauty standards, such ambivalence needs little explanation.
But Sicardi interweaves deeper strands: the beauty industry’s relationship to the climate crisis, the markup on basic goods like shampoo in US prisons and how the history of nail salons in the US relates to the Vietnam war.

Yet Sicardi describes themselves as “devoted to telling stories about the beauty industry” because of its ability to bring people together and provide comfort – as with the monthly nail appointments they describe as “one of the only indulgences I could afford” in their early 20s.

I spoke to Sicardi about the beauty industry’s hideous parts: exploitative work conditions, overconsumption and Coco Chanel’s links to fascism. Our conversation was edited for length and clarity.

The first chapter in The House of Beauty is a “choose your own adventure”-style tale navigating the manufacturing, marketing and sales process of a beauty product.

How did you come up with that structure?
I wanted to showcase how complicated and interconnected the beauty industry is to so many other industries, in a way that people could play through with friends and talk about and understand there’s infinite possibilities – and they’re all interconnected.

I think people come in with a set of expectations of what writing about beauty should look like, and I wanted to throw that out the window and violently explode it before they proceeded to the rest of the book.

You don’t shy away from devastating facts in that chapter – you refer to workers’ deaths and child labor. It’s affecting and pretty stressful to read.

That was intentional. I did multiple interviews a week for years, with people all around the world, with three translators, via email and Zoom and in person.

I interviewed every type of person that’s mentioned: auditors, NGO people that directly interact with and record the deaths of child laborers, farmers, retail associates, cosmetic chemists, lawyers, CEOs.

I didn’t talk to the assassin [one vignette features the point of view of an assassin who kills a lawyer representing peasant farmers in Honduras] – unfortunately, they were not easily accessible.

Ultimately, we are all participants and complicit in how beauty is produced throughout the world.
I wanted the reader to be immediately implicated in the story, like you are the final girl in this horror movie.

The current political moment illustrates how fashion, beauty and fascism are intertwined.
But your chapter about Coco Chanel – who had a Nazi lover and tried to use Nazi laws in order to wrest control of her perfume business from its Jewish owners – shows that it’s not unique to the present.

I’ve always been fascinated with the story of Chanel, because I didn’t really understand why this huge part of her history was swept away.

But being confused by it was a kind of naivety about how power relations work and how beneficial complicity is to people who are afraid of moral consequences.

For years, I wondered why she did not use her power to effect better kinds of change given the circumstances. But she was never going to be a good person.

She didn’t grow up surrounded by people with different politics around her.
She grew up in antisemitism in a time where that was pretty normal and normalized, and the people that she found value and camaraderie with believed the same thing that she did.

She lived in a very particular privileged bubble, and wanted to continue to live in the bubble the worse the world got.

I think a lot of people probably relate a little too much to Chanel, frankly, in this day and age.
I wanted to tell a story of how complicated her life was, and how much the questions she was confronted with are questions that we are also confronted with.

It’s certainly not a chapter that excuses her behavior. It’s not a feelgood chapter, but I thought it was a really important story on how we have to hold ourselves accountable.

Despite its darker sides, you also write about the sense of community the beauty world can foster. How has it done that for you personally?

I see beauty as a tool for connection and opportunity.
A lot of the time, as I’ve reported in this book, it’s used to exploit us and other times it is used to bring us together and take care of the most vulnerable.

I used to do mutual aid fundraisers by collecting beauty products from different magazines’ beauty closets, and pooling these resources and putting the money towards bail funds, abortion funds and immigrant legal funds.

I really love fragrance, and I am doing fragrance swaps as part of the book tour, as a way to share resources and materials. It’s like a gateway to community.

People leave with more than they came with: new friends or opportunities for friendships. You can bring something you don’t want and leave with something you’re excited by.

skip past newsletter promotion Sign up to Well Actually Free weekly newsletter Practical advice, expert insights and answers to your questions about how to live a good life Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion
I’m pretty uninterested in and disloyal to products. I don’t do brand sponsorships or collaborations, even though I came from an influencer background and I grew up as an OG influencer.

I have loyalty to people and to the stories that we want to share together.
That doesn’t make me brand friendly, but it does mean that I am more likely to foster community and people want to show up because we share the same ideals.

You cite a statistic that Americans are spending $3,342 on beauty services and cosmetics a year, on average. But items like soap and toothpaste are a necessity. So what do we do?

How do we make ethical choices?
I don’t have a perfect answer, but it’s not about perfection – it’s about progress.
I am not going to say that it’s up to the individual consumer – that would be such a disservice to the scale of the problem and our individual agency.

You can DIY your own products for the rest of your life and recycle properly and be a complete martyr of pure, ethical, moral good and it will still not make a dent in comparison to Elon Musk’s personal habits over the course of an hour.

The scale of power and waste between 1% of the world to everyone else is so wildly disproportionate.
But that isn’t a license for us to just keep buying whatever we want. Being defeatist doesn’t serve any of us.

It’s really about figuring out the best-case scenario for you and for your immediate community, sharing that knowledge and having a long-term actionable goal that you all work towards together.

But here’s an easy thing to do: you don’t need one-use products, like sheet masks. Bar soap takes up less resources. You don’t necessarily need a 15-step skin care routine.

You simply use less and keep it moving.
Why did you decide to conclude the book discussing this idea of care and community?
Well, I needed to not go insane. From the beginning draft to the early reads, it was a 10-year process, which is a gloriously privileged amount of time to spend on any creative project.

At least five or six of those years were dedicated to researching and sitting in some of the worst things that we’ve done to each other as humans.

I didn’t want to break my own heart infinitely, so I needed to find a balance.
I had to sit and ask myself, like, it’s not all horrible, right? I had to find the light throughout the stories and collect it for myself.

My guiding force and my guiding principle was that beauty is terror but it’s also an act of care, and that matters as much.

Care always exists even in precarity, and that’s something I had to remind myself in the end. I didn’t want to leave everyone feeling devastated, because that’s not where I landed either.

## 📅 관련 노트
- 일간 정리: [[2025-11-08]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22