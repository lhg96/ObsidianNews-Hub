---
title: The Guardian 뉴스
source: The Guardian
type: source-index
tags: [뉴스, 소스별정리]
---

# 📺 The Guardian

**총 기사 수**: 51개

## 2025-11-12
- [Starmer says any attack on his cabinet is ‘completely unacceptable’ and adds Streeting is doing a great job – UK politics live](https://www.theguardian.com/politics/live/2025/nov/12/keir-starmer-wes-streeting-labour-leadership-pmqs-kemi-badenoch-conservatives-uk-politics-live-news)
- [Night of the Juggler review – full-throttle 1980s pulp shocker crammed with nonstop gonzo mayhem](https://www.theguardian.com/film/2025/nov/12/night-of-the-juggler-review-1980s-full-throttle-pulp-shocker-crammed-with-nonstop-gonzo-mayhem)
- [Parking passes at 2026 World Cup will cost as much as $175 per vehicle](https://www.theguardian.com/football/2025/nov/12/world-cup-2026-parking-prices)
- [Ferry company apologises after children left ‘screaming’ by pornographic film](https://www.theguardian.com/uk-news/2025/nov/12/ferry-company-apologises-pornographic-film-dfds)
- [Why the first ball of the Ashes is both an end and a beginning](https://www.theguardian.com/sport/2025/nov/12/the-ashes-first-ball-series-spin-newsletter)
- [Predators review – grimly compelling look at reality TV revenge hunt for child abusers](https://www.theguardian.com/film/2025/nov/12/predators-review-grimly-compelling-look-at-reality-tv-revenge-hunt-for-child-abusers)
- [Yes, New York will soon be under new management. But Zohran Mamdani is just the start | Carys Afoko](https://www.theguardian.com/commentisfree/2025/nov/12/yes-new-york-will-soon-be-under-new-management-but-zohran-mamdani-is-just-the-start)
- [Haftbefehl shows that Germany loves art born from alienation – just not the people who create it](https://www.theguardian.com/music/2025/nov/12/germany-merz-haftbefehl-netflix-documentary)
- [Donald Trump says he has ‘obligation’ to sue BBC over speech edit](https://www.theguardian.com/media/2025/nov/12/donald-trump-says-he-has-obligation-to-sue-bbc-over-speech-edit)
- [Actor Allison Mack reveals role in Nxivm sex cult in new podcast: ‘I was abusive’](https://www.theguardian.com/us-news/2025/nov/12/allison-mack-nxivm-sex-cult-podcast)
- [My jelly hell: ‘Slowly, the whole thing collapsed before me’](https://www.theguardian.com/food/2025/nov/12/my-jelly-hell-slowly-the-whole-thing-collapsed-before-me)
- [‘We need an iron fist’: the Trump-inspired favourite to win Chile’s election](https://www.theguardian.com/world/2025/nov/12/jose-antonio-kast-trump-inspired-frontrunner-chile-president)
- [Being Eddie review – reverential Netflix doc paints limited portrait of Eddie Murphy](https://www.theguardian.com/film/2025/nov/12/being-eddie-review-netflix-doumentary)
- [‘Attacked no matter what they do’: why female politicians face relentless cycle of abuse](https://www.theguardian.com/world/2025/nov/12/female-politicians-such-as-mexicos-claudia-sheinbaum-face-backlash-driven-by-discrimination)
- [A Merry Little Ex-Mas review – Netflix’s season of cheap Christmas spirit starts with a shrug](https://www.theguardian.com/film/2025/nov/12/a-merry-little-ex-mas-netflix-movie-review)
- [Son Heung-min’s legacy: Asian fans are Tottenham for life after trailblazing impact](https://www.theguardian.com/football/2025/nov/12/son-heung-min-legacy-asian-fans-tottenham-for-life-spurs)
- [‘The future is female’: Claudia Rizzo flies flag for women in Italian football](https://www.theguardian.com/football/2025/nov/12/future-is-female-claudia-rizzo-ternana-women-italian-football)
- [Gen Z’s ‘first lady’: how Rama Duwaji, Mamdani’s wife, speaks to a new era of political fashion](https://www.theguardian.com/fashion/2025/nov/12/rama-duwaji-zohran-mamdani-style-politics)
- [Susie Wolff: ‘I can be very punchy and pragmatic. If I have to fight for something, I’ll fight’](https://www.theguardian.com/sport/2025/nov/12/susie-wolff-f1-academy-female-drivers-interview)
- [‘I’ll be executed on Tuesday’: families reveal panicked last calls from foreigners on Saudi’s death row](https://www.theguardian.com/global-development/2025/nov/12/foreign-prisoners-killed-saudi-arabian-jail-tabuk-prison-egyptians-executed-non-violent-drug-crimes-mohammed-bin-salman)
- [John F Kennedy’s grandson Jack Schlossberg announces run for US House seat](https://www.theguardian.com/us-news/2025/nov/12/jack-schlossberg-jfk-john-f-kennedy-grandson-congress)
- [There’s a missing link in British public life – and it underpins crises from the BBC to our prisons | Rafael Behr](https://www.theguardian.com/commentisfree/2025/nov/12/british-public-life-bbc-prisons-identity)
- [‘This is fascist America’: Anish Kapoor may sue after border agents pose by his sculpture](https://www.theguardian.com/artanddesign/2025/nov/12/anish-kapoor-may-sue-border-agents-pose-by-sculpture)
- [Sex, lies and pistachio shells: the disturbing dream worlds of artist Joseph Yaeger](https://www.theguardian.com/artanddesign/2025/nov/12/joseph-yaeger-interview-painter-polygrapher)
- [‘Atrocious on every level’: sex case findings shame New Zealand’s senior police culture](https://www.theguardian.com/world/2025/nov/12/new-zealand-police-sex-case-findings-ntwnfb)
- [Worth a shout? Yelling is best way to deter gulls, UK study suggests](https://www.theguardian.com/science/2025/nov/12/yelling-best-way-deter-gulls-uk-study-suggests)
- [‘I don’t want anyone to suffer like I did’: the intersex campaigners fighting to limit surgery on children](https://www.theguardian.com/society/2025/nov/12/intersex-campaigners-fighting-to-limit-surgery-on-children)
- [Japan’s new PM faces sumo-sized dilemma: will Takaichi defy the sport’s ban on women?](https://www.theguardian.com/world/2025/nov/12/japan-pm-sumo-wrestling-ban-women)
- [Thousands protest Jared Kushner-linked development on site of bombed-out Belgrade building](https://www.theguardian.com/world/2025/nov/12/jared-kushner-protest-belgrade-building-serbia)
- [The Guardian view on Fifa’s new ‘peace prize’: Gianni Infantino should concentrate on the day job | Editorial](https://www.theguardian.com/commentisfree/2025/nov/11/the-guardian-view-on-fifas-new-peace-prize-gianni-infantino-should-concentrate-on-the-day-job)
- [Ben Jennings on Cop30 – cartoon](https://www.theguardian.com/commentisfree/picture/2025/nov/11/ben-jennings-on-cop30-cartoon)
- [‘It’s notoriously hard to write about sex’: David Szalay on Flesh, his astounding Booker prize-winner](https://www.theguardian.com/books/2025/nov/11/its-notoriously-hard-to-write-about-sex-david-szalay-flesh-booker-prize-winner)

## 2025-11-11
- [Carnival season in Germany and Armistice Day services: photos of the day – Tuesday](https://www.theguardian.com/news/gallery/2025/nov/11/carnival-season-germany-armistice-day-photos-of-the-day-tuesday)
- [‘Fashion exposes people’s desires and anxieties’: how much do we really reveal when we get dressed?](https://www.theguardian.com/fashion/2025/nov/11/fashion-exhibition-fit-new-york-dress-dreams-and-desire)
- [‘It’s changed me’: Jeff Goldblum says he has stopped eating meat after working on Wicked](https://www.theguardian.com/culture/2025/nov/11/jeff-goldblum-stopped-eating-meat-after-working-on-wicked)
- [‘We were effectively props’: young stars of game development feel let down by the ‘gaming Oscars’](https://www.theguardian.com/games/2025/nov/11/future-class-gamings-oscars-game-awards)
- [Waiting for the tsunami: its big waves are loved by surfers – but this Canadian town is braced for disaster](https://www.theguardian.com/environment/2025/nov/11/canada-tofino-disasters-earthquakes-tsunami-tourism-tectonics)
- [‘I can see a world where Spotify doesn’t exist’: will a new generation of music streaming companies succeed?](https://www.theguardian.com/music/2025/nov/11/spotify-music-streaming-companies)
- [Love Immortal: the man devoted to defying death through cryonics – documentary](https://www.theguardian.com/film/ng-interactive/2025/nov/11/love-immortal-the-man-devoted-to-defying-death-through-cryonics-documentary)
- [Next day delivery, no weapons allowed: the unstoppable postal service keeping Ukraine going](https://www.theguardian.com/world/2025/nov/11/car-bumpers-homemade-pies-no-weapons-allowed-the-unstoppable-postal-service-keeping-ukraine-going)
- [Vaim by Jon Fosse review – the Nobel laureate performs a strange miracle](https://www.theguardian.com/books/2025/nov/11/vaim-by-jon-fosse-review-the-nobel-laureate-performs-a-strange-miracle)
- [From the Andes to the Amazon: a six-week riverboat adventure to Belém, Brazil’s gateway to the river](https://www.theguardian.com/travel/2025/nov/11/andes-to-the-amazon-riverboat-adventure-to-belem-brazil-cop30)
- [‘I opened up like a giant elevator’: the seven sly, savage stages of a £100,000 romance scam](https://www.theguardian.com/lifeandstyle/2025/nov/11/seven-sly-savage-stages-of-a-romance-scam)
- [The risky strategy of Booker winner Flesh pays off](https://www.theguardian.com/books/2025/nov/10/booker-winner-flesh-david-szalay-biggest-metaphysical-questions)

## 2025-11-10
- [‘Young audiences are less scared of it’: why London jazz clubs are expanding and thriving against the odds](https://www.theguardian.com/music/2025/nov/10/london-jazz-clubs-expanding-thriving-against-the-odds-jazz-cafe-ronnie-scotts-blue-note)
- [Michelle Obama dishes the secrets behind her most famous outfits: best podcasts of the week](https://www.theguardian.com/tv-and-radio/2025/nov/10/michelle-obama-dishes-the-secrets-behind-her-most-famous-outfits-best-podcasts-of-the-week)

## 2025-11-09
- [‘Too far? I don’t think we’ve gone far enough!’ The founder of Peta on gruesome stunts and her bloody fight for animal rights](https://www.theguardian.com/us-news/2025/nov/09/ingrid-newkirk-peta-interview-animal-rights)
- [The moment I knew: when we reunited in our 60s, it felt like coming home](https://www.theguardian.com/lifeandstyle/2025/nov/08/moment-i-knew-reunited-in-our-60s-felt-like-coming-home)

## 2025-11-08
- [Guitar Hero at 20 – how a plastic axe bridged the gap between rock generations](https://www.theguardian.com/games/2025/nov/08/guitar-hero-at-20-gap-between-rock-generations-harmonix-redoctane)
- [I’m a food writer with a binge-eating disorder, and I’m learning to reject shame](https://www.theguardian.com/lifeandstyle/2025/nov/08/food-writer-with-binge-eating-disorder)
- [Lipstick, manicures ... and fascism: the ugliness behind the $450bn beauty industry](https://www.theguardian.com/wellness/2025/nov/07/beauty-industry-arabelle-sicardi-book)
