---
title: "Love Immortal: the man devoted to defying death through cryonics – documentary"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 19:33
url: https://www.theguardian.com/film/ng-interactive/2025/nov/11/love-immortal-the-man-devoted-to-defying-death-through-cryonics-documentary
type: news-article
tags:
  - 뉴스
  - The Guardian
  - original
  - reporting
  - incisive
  - analysis
  - direct
  - guardian
  - every
  - morning
---

# Love Immortal: the man devoted to defying death through cryonics – documentary

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 19:33 |
| **원문링크** | [바로가기](https://www.theguardian.com/film/ng-interactive/2025/nov/11/love-immortal-the-man-devoted-to-defying-death-through-cryonics-documentary) |

## 📝 요약
> <p>Alan, 87, has devoted his life to trying to defy death, and has promised his wife, Sylvia, that they will be cryogenically preserved upon death to be reunited in the future. However, when Sylvia dies all too soon, Alan unexpectedly falls in love with another woman and is forced to reconsider his future plans. An extraordinary love story, told with humour and tenderness about how we deal with loss, our own mortality and the prospect of eternal life.</p> <a href="https://www.theguardian.com/film/ng-interactive/2025/nov/11/love-immortal-the-man-devoted-to-defying-death-through-cryonics-documentary">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `original` | `reporting` | `incisive`

**태그**: #original #reporting #incisive #analysis #direct #guardian

## 📰 본문

Original reporting and incisive analysis, direct from the Guardian every morning

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22