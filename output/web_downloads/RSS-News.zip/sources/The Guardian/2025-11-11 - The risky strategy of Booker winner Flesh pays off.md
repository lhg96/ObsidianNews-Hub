---
title: "The risky strategy of Booker winner Flesh pays off"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 07:00
url: https://www.theguardian.com/books/2025/nov/10/booker-winner-flesh-david-szalay-biggest-metaphysical-questions
type: news-article
tags:
  - 뉴스
  - The Guardian
  - about
  - novel
  - flesh
  - szalay
  - life
  - istv
  - into
  - stories
authors: Justine Jordan
---

# The risky strategy of Booker winner Flesh pays off

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 07:00 |
| **저자** | Justine Jordan |
| **원문링크** | [바로가기](https://www.theguardian.com/books/2025/nov/10/booker-winner-flesh-david-szalay-biggest-metaphysical-questions) |

## 📝 요약
> <p>The protagonist’s inner life is hidden from the reader in this highly original novel</p><ul><li><p><a href="https://www.theguardian.com/books/2025/nov/10/david-szalay-wins-2025-booker-prize-for-dark-flesh">David Szalay wins 2025 Booker prize for ‘dark’ Flesh</a></p></li></ul><p>Reflecting on the Booker judging process, chair Roddy Doyle stressed the “singularity” of <a href="https://www.guardianbookshop.com/flesh-9780224099783/?utm_source=editoriallink&amp;utm_medium=merch&amp;utm_campaign=article">Flesh</a>, the most unusual novel on the shortlist. In his sixth book, Hungarian-British writer David Szalay takes a classic story arc – one man’s journey through life, from childhood to old age – and presents it in a radically new and challenging way, scooping out the interiority that usually powers the novel form.</p><p>We meet his protagonist, István, as a bored 15-year-old in a Hungarian backwater. He is seduced by a middle-aged neighbour into a relationship suffused with shame and disgust; a confused act of violence knocks his life off course; he joins the military and is stationed in Kuwait; he moves to London and works as a bouncer before the rising tides of global capital carry him, for a while, into the monied elite. And all the while, we are cut off from his thoughts, emotions and motivations: we see only how others react to him, desire him, fear him. The most we tend to hear from István himself is a bland, noncommittal “OK”.</p><p>Flesh by David Szalay (Vintage Publishing, £18.99). To support the Guardian, order your copy for £16.14 at <a href="https://www.guardianbookshop.com/flesh-9780224099783/?utm_source=editoriallink&amp;utm_medium=merch&amp;utm_campaign=article">guardianbookshop.com</a>. Delivery charges may apply.</p> <a href="https://www.theguardian.com/books/2025/nov/10/booker-winner-flesh-david-szalay-biggest-metaphysical-questions">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `about` | `novel` | `flesh`

**태그**: #about #novel #flesh #szalay #life #istv

## 📰 본문

Reflecting on the Booker judging process, chair Roddy Doyle stressed the “singularity” of Flesh, the most unusual novel on the shortlist.

In his sixth book, Hungarian-British writer David Szalay takes a classic story arc – one man’s journey through life, from childhood to old age – and presents it in a radically new and challenging way, scooping out the interiority that usually powers the novel form.

We meet his protagonist, István, as a bored 15-year-old in a Hungarian backwater.
He is seduced by a middle-aged neighbour into a relationship suffused with shame and disgust; a confused act of violence knocks his life off course; he joins the military and is stationed in Kuwait; he moves to London and works as a bouncer before the rising tides of global capital carry him, for a while, into the monied elite.

And all the while, we are cut off from his thoughts, emotions and motivations: we see only how others react to him, desire him, fear him.

The most we tend to hear from István himself is a bland, noncommittal “OK”.
It’s a risky strategy, but this narrative flatness hugely pays off: it entices the reader into the yawning gaps in the text as we work to solve the puzzle of István, and it turns a story about one man’s vulnerability in the face of the buffeting winds of fate, and of meaningless, out-of-the-blue tragedy, into a propulsive page-turner.

Its starkness blows the biggest metaphysical questions about identity, free will and the purpose of life wide open.

From his 2008 debut London and the South-East, set in the world of telesales, to his 2016 Booker-shortlisted novel-in-stories All That Man Is, a kaleidoscopic portrait of men at different stages of life, Szalay has followed his own path.

He’s fascinated by masculinity, repression, status and sex, as well as migration and the rootless nowhere-places of contemporary Europe.

Often he focuses on the kind of working-class male characters who, as Doyle said, don’t usually get “much of a look-in” in literary fiction.

The understatedness of the dialogue in Flesh is the endpoint of a bold quest for realism – “the way”, as Szalay has pointed out in an interview, “that people actually speak”.

His use of white space in Flesh – the gaps between chapters, in which critical events happen offstage, mirroring the gaps between characters – is also familiar from previous work.

The stories in All That Man Is directed a laser-like focus on brief moments in various lives, which together added up to so much more than the sum of their parts.

Flesh could also be seen as a novel in short stories, the unwritten and unspoken sections carrying their own power and mystery.

Szalay has always been interested in how much the writer can leave out: his 2018 story collection, Turbulence, structured as a series of plane journeys, crisscrossed the globe in fewer than 150 pages.

The prose was simple and declarative, but untold depths of emotion brimmed in the spaces between sentences.

The question of where our emotions originate, in mind or body, and the interplay between the two is an endlessly fertile one; Szalay has described Flesh as stemming from “the feeling I had that our existence is a physical experience before it is anything else”.

The primacy the novel gives to the demands and impulses of the body is another thing that marks it out, especially at a time when so much of life is lived online.

This may be a bleak book, but it offers the pleasures of a surprising and difficult thing done very well (though the focus does wobble a little towards the end, when the narrative attention follows characters other than István).

Its originality makes it a novel you will think about as well as feel, like a gut punch, in your body.

skip past newsletter promotion Sign up to Bookmarks Free weekly newsletter Discover new books and learn more about your favourite authors with our expert reviews, interviews and news stories.

Literary delights delivered direct to you Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22