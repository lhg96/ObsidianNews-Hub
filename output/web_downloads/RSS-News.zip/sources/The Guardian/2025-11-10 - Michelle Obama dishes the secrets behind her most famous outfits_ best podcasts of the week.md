---
title: "Michelle Obama dishes the secrets behind her most famous outfits: best podcasts of the week"
source: The Guardian
date: 2025-11-10
datetime: 2025-11-10 16:00
url: https://www.theguardian.com/tv-and-radio/2025/nov/10/michelle-obama-dishes-the-secrets-behind-her-most-famous-outfits-best-podcasts-of-the-week
type: news-article
tags:
  - 뉴스
  - The Guardian
  - about
  - weekly
  - widely
  - available
  - episodes
  - your
  - information
  - newsletter
authors: Hannah J Davies, Hollie Richardson, Alexi Duggins
---

# Michelle Obama dishes the secrets behind her most famous outfits: best podcasts of the week

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-10 16:00 |
| **저자** | Hannah J Davies, Hollie Richardson, Alexi Duggins |
| **원문링크** | [바로가기](https://www.theguardian.com/tv-and-radio/2025/nov/10/michelle-obama-dishes-the-secrets-behind-her-most-famous-outfits-best-podcasts-of-the-week) |

## 📝 요약
> <p>The former First Lady hosts an absorbing new show about her fashion evolution. Plus, Katy Davis explores ‘waiting’ – whether it’s for a bus or an imprisoned lover</p> <a href="https://www.theguardian.com/tv-and-radio/2025/nov/10/michelle-obama-dishes-the-secrets-behind-her-most-famous-outfits-best-podcasts-of-the-week">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `about` | `weekly` | `widely`

**태그**: #about #weekly #widely #available #episodes #your

## 📰 본문

Pick of the week
IMO: The Look
This new spin-off of Michelle Obama’s IMO podcast coincides with the launch of a coffee-table tome about her fashion evolution.

It’s a highly polished affair (aren’t all things Obama?), with guests including former Teen Vogue editor Elaine Welteroth and Jane Fonda.

Like the woman herself, though, it also offers substance alongside its style, revealing much about the pressures she faced as the first Black woman to reside in the White House. Hannah J Davies

Widely available, episodes weekly
On Hold
Test results. The bus. Your wedding day. We all know the mixed emotions that come with anticipation. But what about waiting for a lover in prison? The arrival of a surrogate baby?

Or the time between death and being resuscitated back to life? In this thoughtful series, Katy Davis hears extraordinary stories of navigating such uncertainty. Hollie Richardson

Widely available, episodes weekly
The Preventionist
View image in fullscreen Investigative … Dyan Neary, host of The Preventionist podcast. Photograph: PR IMAGE

The New York Times’s Serial Productions has form in hard-hitting investigations into contentious subjects, and this series is no exception.

Dyan Neary (pictured) meets parents whose children were removed from their care after allegations of abuse were made by the same doctor, and asks whether a “better safe than sorry” approach was the right one.

HJD
Widely available, episodes weekly
Disclosure
Freedom of information requests aren’t the sexiest topic, but investigative reporter Jason Leopold and First Amendment attorney Matt Topic turn them into a lively listen.

The stories they’ve unearthed by using them in the US include getting Donald Trump’s chief of staff to admit to a court that the president doesn’t mean what he tweets. Alexi Duggins

Widely available, episodes weekly
skip past newsletter promotion Sign up to What's On Free weekly newsletter Get the best TV reviews, news and features in your inbox every Monday Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion
The Europeans: Who Does It Best?
A new miniseries puts EU nations head to head on housing, childcare and drug policy to find out the best.

The childcare episode looks at issues from Iceland’s women’s strike to the fact that much-vaunted Sweden nightmarishly limits childcare for toddlers if their parents have another baby.

The finest provider of childcare? It’s not Scandinavian. AD
Widely available, episodes weekly

## 📅 관련 노트
- 일간 정리: [[2025-11-10]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22