---
title: "The moment I knew: when we reunited in our 60s, it felt like coming home"
source: The Guardian
date: 2025-11-09
datetime: 2025-11-09 04:00
url: https://www.theguardian.com/lifeandstyle/2025/nov/08/moment-i-knew-reunited-in-our-60s-felt-like-coming-home
type: news-article
tags:
  - 뉴스
  - The Guardian
  - paul
  - family
  - again
  - then
  - never
  - life
  - there
  - knew
authors: Doosie Morris
---

# The moment I knew: when we reunited in our 60s, it felt like coming home

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-09 04:00 |
| **저자** | Doosie Morris |
| **원문링크** | [바로가기](https://www.theguardian.com/lifeandstyle/2025/nov/08/moment-i-knew-reunited-in-our-60s-felt-like-coming-home) |

## 📝 요약
> <p><strong>Lynne Besant</strong> met Paul as a teenager. After 40 years apart, she discovered she still had feelings for him</p><ul><li><p>Find more stories from <a href="https://www.theguardian.com/lifeandstyle/series/the-moment-i-knew">the moment I knew series</a></p></li></ul><p>In the mid-60s, my family followed my father’s work to a caravan park in Gladstone, central Queensland. He worked in construction and the sprawling transient accommodation for the hundreds of families who’d relocated to build an aluminium plant became our home. I was going on 16 and sulking about having to change schools, again. Then I met Paul.</p><p>Back in those days people made their own fun. We often had huge parties at the caravan park, and Paul, an apprentice electrician, would volunteer to rig up the lighting.</p> <a href="https://www.theguardian.com/lifeandstyle/2025/nov/08/moment-i-knew-reunited-in-our-60s-felt-like-coming-home">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `paul` | `family` | `again`

**태그**: #paul #family #again #then #never #life

## 📰 본문

In the mid-60s, my family followed my father’s work to a caravan park in Gladstone, central Queensland.

He worked in construction and the sprawling transient accommodation for the hundreds of families who’d relocated to build an aluminium plant became our home.

I was going on 16 and sulking about having to change schools, again. Then I met Paul.
Back in those days people made their own fun. We often had huge parties at the caravan park, and Paul, an apprentice electrician, would volunteer to rig up the lighting.

View image in fullscreen Paul and Lynne in Queensland in 1967
Despite the age difference (he’d just turned 21), we became friendly. My parents and I were sharing a 15ft caravan, and while they adored Paul, he was never allowed inside.

For two years we’d spend hours under the awning chatting away.
He’d pick me up from my ballet classes, and on Friday night we’d get fish and chips with my parents and sit on a little hill overlooking the beach drinking cheap white wine.

In the most innocent way I considered him my boyfriend, and he sort of became part of the family.
My mother was mildly horrified when he gave me a friendship ring but I wore it so proudly and still have it today. I was incredibly naive, but Paul was always so respectful.

Then my family packed up again and I spent months sending Paul lovelorn letters from Darwin, on pastel purple paper drowned in Imprevu perfume.

Eventually the letters stopped and life moved on.
I finished school and set off on a big American road trip on the way to Central America: LA, New Orleans, Florida and then spent about seven months staying with a family friend on an oil rig encampment in Venezuela, surrounded by barbed wire and guards.

Meanwhile, little did I know that Paul had washed up in Darwin looking for me.
For reasons we’ve never really been able to work out, my mother took him in and encouraged him to save money to meet me in the United States.

Communicating via snail mail, we arranged to meet in Miami. He booked two hotel rooms, but we only used one. We didn’t leave the hotel for days – I guess we were making up for lost time.

As he says, “We lived on room service and love, at last.”
We started Greyhound hopping, travelling where the wind blew us. We were in Orlando for the opening weekend of Disney World in 1971 and stayed in the resort there.

They had some wandering musicians who took requests, and we had them perform Moon River for us.
I knew then the relationship had really taken off and I never heard that song again without thinking of him.

View image in fullscreen Lynne and Paul on their travels in Rangoon, Myanmar, circa 1971
We travelled to the UK and finally found our way home to Darwin by Christmas. There, Paul asked my father for my hand in marriage.

He was OK with it, but once again my mother baffled us all by totally disapproving, despite the fact she’d been the one who encouraged him to come and meet me overseas.

I don’t know what she thought was going to happen on that trip, but I guess us getting married at the end wasn’t part of her plan.

Things between me and Paul fell apart after that, yet he remained firm friends with my family and all our friends, so I always knew what was going on in his life.

Paul married, had a family and built his own boat, taking eight years to sail it from Australia to the Mediterranean.

Despite all his adventures and happy marriage, he says he always held a flame for me.
By 2011 I had two adult children, had been divorced for over a decade and was living in Perth.
Paul tracked me down and what was supposed to be a friendly catch-up at a cafe while he was visiting for work eventually spiralled into much more.

My friends thought I was crazy for getting caught up with my still-married childhood sweetheart, but in the 40 years we’d been apart I’d never felt anything like the feelings I still had for Paul.

We handled things as respectfully as possible but that doesn’t mean people weren’t hurt. It has taken time to rebuild some relationships that were damaged.

In 2015 we walked to our beachfront altar to Moon River.
Every time Paul has come into my life there have been moments I knew he was the one for me. But when you are young you can be blind to how rare they are in life.

It was only with the benefit of hindsight that we could both fully grasp how profound our connection was.

While there were a few lighting bolts along the way, ours was a slow burn. When we reunited in our 60s it felt, quite simply, like coming home.

Tell us the moment you knew

## 📅 관련 노트
- 일간 정리: [[2025-11-09]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22