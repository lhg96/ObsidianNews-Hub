---
title: "Vaim by Jon Fosse review – the Nobel laureate performs a strange miracle"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 16:00
url: https://www.theguardian.com/books/2025/nov/11/vaim-by-jon-fosse-review-the-nobel-laureate-performs-a-strange-miracle
type: news-article
tags:
  - 뉴스
  - The Guardian
  - jatgeir
  - eline
  - fosse
  - more
  - vaim
  - about
  - dream
  - reality
authors: Sukhdev Sandhu
---

# Vaim by Jon Fosse review – the Nobel laureate performs a strange miracle

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 16:00 |
| **저자** | Sukhdev Sandhu |
| **원문링크** | [바로가기](https://www.theguardian.com/books/2025/nov/11/vaim-by-jon-fosse-review-the-nobel-laureate-performs-a-strange-miracle) |

## 📝 요약
> <p>In the Norwegian master’s latest example of ‘mystical realism’, one man makes a dreamlike, hypnotic voyage through life</p><p>“I have always known that writing can save lives,” said the Norwegian author Jon Fosse in his speech accepting the 2023 Nobel prize in literature. “And if my writing also can help to save the lives of others, nothing would make me happier.” Rare is the novelist who talks in such language these days: fiction tends to know its modest place. Fosse, who is also a poet and an essayist, and one of the most widely performed playwrights in the world, follows his own path. A case in point: Septology (2019-2021), published across three volumes, running to more than 800 pages, containing a single sentence. Forget formalism, though; his fictions, often set in fjordic Norway, are disintegration loops, quiet and incantatory, emotionally overwhelming.</p><p>At fewer than 120 pages, Vaim, his first new work since winning the Nobel, is a wisp of a thing. Divided into three sections, each narrated by a different character, it begins with Jatgeir sailing on a small boat from the small town of Vaim to the big city of Bjørgvin. His mission is to buy a needle and thread to fix a missing button. It’s a long journey and, not just at one shop but at two, he gets royally ripped off, being charged far over the odds for a single spool. He huffs and seethes, but says nothing to the storekeepers themselves. What a hick, we might think. What a chump.</p> <a href="https://www.theguardian.com/books/2025/nov/11/vaim-by-jon-fosse-review-the-nobel-laureate-performs-a-strange-miracle">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `jatgeir` | `eline` | `fosse`

**태그**: #jatgeir #eline #fosse #more #vaim #about

## 📰 본문

“I have always known that writing can save lives,” said the Norwegian author Jon Fosse in his speech accepting the 2023 Nobel prize in literature.

“And if my writing also can help to save the lives of others, nothing would make me happier.” Rare is the novelist who talks in such language these days: fiction tends to know its modest place.

Fosse, who is also a poet and an essayist, and one of the most widely performed playwrights in the world, follows his own path.

A case in point: Septology (2019-2021), published across three volumes, running to more than 800 pages, containing a single sentence.

Forget formalism, though; his fictions, often set in fjordic Norway, are disintegration loops, quiet and incantatory, emotionally overwhelming.

At fewer than 120 pages, Vaim, his first new work since winning the Nobel, is a wisp of a thing.
Divided into three sections, each narrated by a different character, it begins with Jatgeir sailing on a small boat from the small town of Vaim to the big city of Bjørgvin.

His mission is to buy a needle and thread to fix a missing button.
It’s a long journey and, not just at one shop but at two, he gets royally ripped off, being charged far over the odds for a single spool.

He huffs and seethes, but says nothing to the storekeepers themselves. What a hick, we might think. What a chump.

Jatgeir, part Prufrock, part sitcom sadsack, lives alone in the house of his dead parents. Its curtains are beige, his hair is greying, occasionally he trims his beard.

Far from rich, he is invisible to the women around him. He often finds himself harking back to Eline, the “secret love of my youth”.

When he named his boat after her, the locals had giggled and she had moved away.
How surprising, then – absurd, even – that on the night of his sewing thread humiliation, he is roused from his sleep by Eline calling his name.

She’d like him, she says, to rescue her from her fisher husband. Back to Vaim they sail.
This could be quite the romance, were it not a Fosse novel. The story stops, is picked up by Jatgeir’s only friend – the religiously minded Elias – only to stop again.

This time the narrative baton is passed on to Frank, the husband Eline had left in the first section. Eline herself, though central to everything that happens, is elusive.

More about her may emerge later (Vaim is the first volume in a planned trilogy), but all that’s revealed here is that she had been “such a silly girl”, left home young and worked for a rich family.

Her ability to make men do her bidding is unnerving, a species of sorcery; she seems spectral, a figure from medieval dream poetry.

Ambiguity mists the whole novel.
Jatgeir wonders if Eline is a mirage, describes their encounter as “incomprehensible, inconceivable”, reflects on how “a dream is a dream and reality is reality, but in a way reality has always been, yes, no, no not like a dream, but reality has had something dreamlike about it too probably my whole life, reality is in the dream the way the boat is in the water”.

Scenes take place in the gloaming, when day commingles with night.
There are mysterious knocks on doors, talk of ghosts, even mention of an institution that often appears in Fosse’s fiction: a madhouse.

How can prose that is so simple – cushions are ‘nice’, work is ‘trusty’ – pulse with such feeling?
The characters are blurry and dissolving, too. Eline, whose name looks close to Elias, wasn’t born Eline.

Jatgeir, whose name isn’t Jatgeir, can’t remember if a niece is called Gudrun Anna or Anna Gudrun.
The men, tending to the passive, are likened to “old maids”; the female characters are purposeful and “masculine”.

Meanwhile, time is bent and inscrutable – bar a fleeting reference to a car, the book could have been set 100 or more years ago.

Invocations of yesteryear and the old days abound, but it’s often left unclear if what’s being alluded to actually happened far more recently.

Fosse has spoken of his fiction as “mystical realism”.
For all the roaming metaphysics and magnificently recursive, hypnagogic rhythms of this one-sentence novel, it’s those passages grounded in the everyday that pop – scenes featuring meatballs and rice pudding, comparisons between American and European suitcases, Jatgeir admitting that for much of his life he had felt closer to boats than to any woman.

(His own he treats with masturbatory care – “I laid my hand flat on a board of the boat and gently rubbed my hand back and forth along the board and then I sat there and I sort of half-dozed off”.)

“All was strange”: that’s what Jatgeir hopes will be written on his tombstone. It’s also the abiding feeling upon finishing Vaim.

How can prose that is so simple – cushions are “nice”, work is “trusty” – pulse with such feeling?
How can it be so littoral, incarnating the light and spray and tidal tempos of these seascapes with such power? And how can a novelist make a reader feel so lost and so found at the same time?

It is strange. A strange miracle.
skip past newsletter promotion Sign up to Inside Saturday Free weekly newsletter The only way to get a look behind the scenes of the Saturday magazine.

Sign up to get the inside story from our top writers as well as all the must-read articles and columns, delivered to your inbox every weekend.

Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22