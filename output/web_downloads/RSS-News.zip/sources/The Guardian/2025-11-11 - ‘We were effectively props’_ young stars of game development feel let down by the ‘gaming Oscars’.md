---
title: "‘We were effectively props’: young stars of game development feel let down by the ‘gaming Oscars’"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 21:30
url: https://www.theguardian.com/games/2025/nov/11/future-class-gamings-oscars-game-awards
type: news-article
tags:
  - 뉴스
  - The Guardian
  - future
  - class
  - game
  - programme
  - awards
  - keighley
  - said
  - inductees
---

# ‘We were effectively props’: young stars of game development feel let down by the ‘gaming Oscars’

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 21:30 |
| **원문링크** | [바로가기](https://www.theguardian.com/games/2025/nov/11/future-class-gamings-oscars-game-awards) |

## 📝 요약
> <p>Announced in 2020 by the Game Awards as an inclusive programme for the industry’s next generation, the Future Class initiative has now been discontinued. Inductees describe clashes with organisers and a lack of support from the beginning</p><p>Video games have long struggled with diversification and inclusivity, so it was no surprise when the Game Awards host and producer Geoff Keighley announced the Future Class programme in 2020. Its purpose was to highlight a cohort of individuals working in video games as the “bright, bold and inclusive future” of the industry.</p><p>Considering the widespread reach of the annual Keighley-led show, which saw an estimated 154m livestreams last year, Future Class felt like a genuine effort. Inductees were invited to attend the illustrious December ceremony, billed as “gaming’s Oscars”, featured on the official Game Awards website, and promised networking opportunities and career advancement advice. However, the programme reportedly struggled from the start. Over the last couple of years, support waned. Now, it appears the Game Awards Future Class has been wholly abandoned.</p> <a href="https://www.theguardian.com/games/2025/nov/11/future-class-gamings-oscars-game-awards">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `future` | `class` | `game`

**태그**: #future #class #game #programme #awards #keighley

## 📰 본문

Video games have long struggled with diversification and inclusivity, so it was no surprise when the Game Awards host and producer Geoff Keighley announced the Future Class programme in 2020.

Its purpose was to highlight a cohort of individuals working in video games as the “bright, bold and inclusive future” of the industry.

Considering the widespread reach of the annual Keighley-led show, which saw an estimated 154m livestreams last year, Future Class felt like a genuine effort.

Inductees were invited to attend the illustrious December ceremony, billed as “gaming’s Oscars”, featured on the official Game Awards website, and promised networking opportunities and career advancement advice.

However, the programme reportedly struggled from the start. Over the last couple of years, support waned. Now, it appears the Game Awards Future Class has been wholly abandoned.

This is the second year in a row Future Class has not announced a new cohort: there are usually 50 inductees across various games industry disciplines, including writing, development, journalism and community management.

As reported by Game Developer, organiser Emily Weir confirmed they “are not planning a new Future Class for [2025] and do not have any active programming plans for Future Class”.

Previous Future Class inductees say this comes after years of internal advocacy and struggles to improve the programme.

With the video game industry wrestling with another culture war over diversity, equity, and inclusivity initiatives (DEI), some members of the Future Class feel they were used for positive publicity, then cast aside when DEI was no longer in vogue.

View image in fullscreen The 2024 ceremony of the Game awards. Photograph: Frank Micelotta/Picturegroup/Shutterstock

“We were effectively props,” game producer Dianna Lora, who was inducted into the first Future Class in 2020, said over video call.

“Once we got to the Game Awards (most people flew in from other countries, which was expensive), we showed up, and it felt like we were pushed to the side door … We found out later that Keighley had a party in another room with all the influencers and industry people.

You know where Future Class met that day? At a Starbucks.”
“No one from official leadership even showed up until the meet-up was basically over,” Future Class member and Retcon Games creative director Jes Negrón said of that Starbucks meeting.

“We were pretty bummed about just being cast aside.”
Elsewhere at that 2021 ceremony, Lora, community manager Natalie Checo, podcast host Kahlief Adams, and other Future Class inductees’ seats were behind one of the camera risers, completely obstructing their view.

Future Class inductees receive programme perks for the next 12 months: a ticket to the Game Awards (alumni were given discounts to buy tickets), and access to career advancement opportunities.

Several people referred to the early career-focused events as chats with high-profile industry members such as former Nintendo president Reggie Fils-Aimé and Xbox head Phil Spencer, rather than proper mentorship programmes.

“It felt like Keighley just called a bunch of his friends to do Zoom calls,” Lora said. “It was inspiring to have these conversations, but that’s really as far as it went.”

Lora was one of several Future Class members who urged Keighley and Weir to improve the programme.
View image in fullscreen Writer Emma Kidwell attending the Game awards in 2022. Photograph: Scott Kirkland/PictureGroup for The Game Awards/Shutterstock

“They fought for everything the 2023 class got: the Future class mixer, [them] putting us up in a hotel for two nights, covering the flight … everything that I got was a result of my previous classmates,” writer and 2023 inductee Emma Kidwell said of previous Future Class inductees.

More recent inductees praised the mentorship opportunities.
But 2023 also saw a high-profile clash between the Future Class and Keighley, which members believe accelerated the programme’s demise.

In November, in the wake of increasing media coverage of the humanitarian crisis in Gaza, more than 70 Future Class members signed an open letter requesting a statement be read at the December ceremony expressing support for Palestine and calling for a ceasefire.

Though it gained media attention and was posted in the Future Class’s Discord, of which both Keighley and Weir belong, the letter was ignored.

Not long after, several Future Class members gave a virtual presentation to Keighley and Weir, acknowledging the importance of the programme while expressing concerns about its “goals, structure, and sustainability”.

They offered suggestions for how to improve both the programme and the awards ceremony in general, such as featuring more female presenters, improved accessibility options, and an acknowledgment of the recent deluge of layoffs in the industry).

Younès Rabii, a 2022 inductee, said that Keighley was visibly frustrated during the call, while another member said he was “incensed”.

Keighley and Weir did not respond to a request for comment.
Every Future Class member who spoke to the Guardian expressed varying levels of frustration with the programme and its untimely ending.

“It’s sad that we were part of something great, that has amazing people, that was left by the wayside,” said accessibility consultant Steve Saylor.

“I’m not mad, I’m disappointed.” Many believed the programme was disbanded because the inductees pushed for a better Future Class.

“You have the influence, you have the power, and you can change sh*t,” Lora said, “But ever since [we pushed back] it was like, ‘This is too much trouble, might as well peace out’.” Checo added: “As a result of advocating for ourselves (the very thing that we were inducted for), we were punished for doing the same thing that they ostensibly celebrated us for.”

View image in fullscreen Geoff Keighley also hosts the annual Summer Game Fest showcase. Photograph: Frank Micelotta/PictureGroup/Shutterstock

A few members wondered about the sponsorships associated with the programme (a video highlighting a 2023 inductee was presented by Old Spice) and if they were just being “tokenised” to help the programme make more money.

(Presenting a one-minute trailer at Keighley’s 2024 summer games showcase reportedly cost $250,000, and sources say the Game Awards is even more expensive.) “They didn’t mention us at the 2022 Game Awards, except for a huge sponsorship that they apparently got in the name of the Future Class, which none of us were told about, and certainly didn’t see any money from,” said Negrón.

At some point, the Future Class page was removed from the Game Awards site, meaning there is no official archive of its members.

“Not only are they discontinuing the programme, but they’ve also eliminated any way for us to claim the honour that they provided,” Checo said.

“Marginalised people need accolades because it pushes them to at least be on the same starting level that you or I might have,” said Kidwell.

“Now people can’t put that on their résumés.” Negrón was curious about the thought process behind it all, saying: “Don’t gather some of the most brilliant activists in the industry, treat us like crap, and then expect us to do nothing about it.”

Many believe Future Class’s failure will serve as a cogent reminder that allyship without proper support is simply performative. And for some, not all is lost.

Midnight Hour founder Elaine Gómez said the “camaraderie and community that was created by bringing nearly 200 developers and creatives from underrepresented communities together” was the best part of it all.

Meanwhile, the official Future Class Discord is still going – and more active now than it has been in the last year or so.

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22