---
title: "Next day delivery, no weapons allowed: the unstoppable postal service keeping Ukraine going"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 18:00
url: https://www.theguardian.com/world/2025/nov/11/car-bumpers-homemade-pies-no-weapons-allowed-the-unstoppable-postal-service-keeping-ukraine-going
type: news-article
tags:
  - 뉴스
  - The Guardian
  - nova
  - poshta
  - says
  - view
  - image
  - fullscreen
  - there
  - branch
authors: Charlotte Higgins, Julia Kochetova
---

# Next day delivery, no weapons allowed: the unstoppable postal service keeping Ukraine going

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 18:00 |
| **저자** | Charlotte Higgins, Julia Kochetova |
| **원문링크** | [바로가기](https://www.theguardian.com/world/2025/nov/11/car-bumpers-homemade-pies-no-weapons-allowed-the-unstoppable-postal-service-keeping-ukraine-going) |

## 📝 요약
> <p>Nova Poshta connects frontline cities to the capital, and to millions of refugees across Europe, delivering everything from home comforts to house moving boxes, even under fire</p><p>In a post office 10 miles (15km) from Ukraine’s frontline, in a suburb of the eastern city of Kharkiv, business is brisk on a chilly autumn morning – despite the ballistic missiles that had shaken the city at midnight, lighting up the sky with a false dawn of flames.</p><p>The customer area is fitted out with phone-charging stations “and a small co-working space, which people can use during blackouts, since we have generators”, says the branch manager, 30-year-old Yaroslav Dobronos. There is also a changing room, in which a young woman is trying on, with a critical gaze, a new pair of jeans, before repacking them and sending them straight back.</p><p>Nova Poshta logistics hub in Kyiv, where packages are moved through a complex set of scanners and chutes before being loaded on to lorries for the journey to their destinations</p> <a href="https://www.theguardian.com/world/2025/nov/11/car-bumpers-homemade-pies-no-weapons-allowed-the-unstoppable-postal-service-keeping-ukraine-going">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `nova` | `poshta` | `says`

**태그**: #nova #poshta #says #view #image #fullscreen

## 📰 본문

In a post office 10 miles (15km) from Ukraine’s frontline, in a suburb of the eastern city of Kharkiv, business is brisk on a chilly autumn morning – despite the ballistic missiles that had shaken the city at midnight, lighting up the sky with a false dawn of flames.

The customer area is fitted out with phone-charging stations “and a small co-working space, which people can use during blackouts, since we have generators”, says the branch manager, 30-year-old Yaroslav Dobronos.

There is also a changing room, in which a young woman is trying on, with a critical gaze, a new pair of jeans, before repacking them and sending them straight back.

Behind the counters, a miscellany of parcels are waiting for customers to collect. Each is a fragment of life lived in all its normality and fragility in a frontline community.

View image in fullscreen Nova Poshta logistics hub in Kyiv, where packages are moved through a complex set of scanners and chutes before being loaded on to lorries for the journey to their destinations

There are winter tyres, widescreen TVs, boxes marked Roshen (a chocolate brand owned by former president Petro Poroshenko), a folding bed, a car bumper, a package from an upmarket Ukrainian skincare brand, a bare-root tree, a set of rucksacks, a pram, a vacuum cleaner, a Russell Hobbs multicooker, and parts for Starlink (a satellite internet provider for use in remote locations).

Out of one enormous, bulbous parcel pokes a fistful of camouflage net.
We provide something of a peaceful life amid the war. In frontline areas, we are the last to leave Yaroslav Dobronos, branch manager

Ukraine’s main postal service is, like the country’s rail network, one of its most vital, reliable arteries: a matter of national pride for Ukrainians and incredulity for visiting foreigners.

Nova Poshta, founded 25 years ago, is one of the chief reasons that Ukraine continues to function during a time of extraordinary violence and peril.

It is affordable – it costs the equivalent of between £1.50 and £2.20 to send packages of between 5kg and 10kg within Ukraine – and it connects citizens across the nation and beyond, including those at the country’s most precarious, threatened edges.

View image in fullscreen View image in fullscreen Top and left: Customer Kyrylo Stepanov sends car parts such as oil and filters by post; right: Starlink components will be delivered by Nova Poshta

“We used to see our jobs here as just work,” says Dobronos. “Now we see that it’s really important. We provide something of a peaceful life amid the war.

In frontline areas, we are the last to leave and the first to come back.”
After the lightning counteroffensive in 2022, for example, Nova Poshta resumed working in the town of Balakliia in the Kharkiv region on 12 September, four days after it was liberated.

In Kherson, on 12 November that year, it delivered lorries of humanitarian aid the day after the Russian withdrawal.

In such situations, the company sets up mobile offices until its premises can be deemed safe from mines, and repaired.

View image in fullscreen A damaged building in northern Kharkiv, which once housed a Nova Poshta branch, October 2025

When Nova Poshta leaves a place, by contrast, there is a sense that it’s the end of the line for a threatened community, one of its most tangible links with the outside world broken.

That was the case in Pokrovsk earlier this year, when its three remaining staff shut the last branch as the Russians pushed closer to the eastern Ukrainian city.

“They worked in a city where there were no more supermarkets, courts, schools, water, gas and electricity, but until now there were a few small grocery stores and the Nova Poshta office,” wrote the company’s co-founder Volodymyr Popereshnyuk in a valedictory Facebook post dated 18 February.

View image in fullscreen Sorting parcels at the Nova Poshta logistics hub in Kyiv
Nova Poshta drivers are still willing to deliver to cities such as Kherson, where vehicles on the roads in and out are cruelly targeted by drones.

Near the frontline, workers are issued with bulletproof vests and helmets.
Back at the customer desk in the Kharkiv suburb, battalion commander Anton Baev, 31, is waiting to send boxes of his girlfriend’s possessions to her new lodgings.

A military psychologist, she had been recently ordered to a new posting. Baev is stationed with his troops nearby.

“If I could get my entire battalion delivered by Nova Poshta, I would do it,” he jokes.
View image in fullscreen Anton Baev, a battalion commander, used the postal service to forward his girlfriend’s possessions

Moving house by post is perfectly normal in Ukraine. “Almost every day we deal with house moves. We deliver furniture, fridges, motorcycles, everything,” says Dobronos.

The postal service provides a lifeline of home comforts to military on the frontline. Weapons are prohibited: “I can’t send a mortar, though that would be nice,” says Baev.

But, aside from perishable food and various hazardous items, more or less anything else can be sent and will usually arrive the next day if dispatched from within the country.

“My mother sent me homemade pie, and it arrived on the frontline,” says Baev.
As the morning drifts on, the air raid siren sounds. The branch is shut swiftly and without drama, then, some moments later, reopens again. Everyone is used to it.

And in any case, in Kharkiv there is a fatalism around missile attacks. “The border is very close,” says Dobronos. “We don’t have much time or much hope for reaction.”

The Kharkiv area premises have two above-ground “capsule” bomb shelters.
Dobronos says: “During an air raid alert, we close the branch and people wait there if they need – inside we have meds, water, fire extinguishers, torches.

“We know it works – when the Russians hit another branch with three Shahed drones, the capsule shelter survived.”

View image in fullscreen Manager Yaroslav Dobronos stands by the ‘capsule’ bomb shelter inside the Nova Poshta branch

One of the office’s more heart-breaking jobs, these days, is dispatching the possessions of fallen soldiers back to their families. “It’s always a weird experience,” says Dobronos.

“Maybe you’ve seen that person in the branch, but you just don’t know.”
During the day, little eddies of queues appear at the customer desks, but quickly disperse as the staff retrieve, or pack and dispatch, parcels at speed.

In contrast to the meditative, slow shuffle to a counter in a busy UK post office, the monthly queue target in this branch is “zero”, and they have slipped only twice, according to a handwritten note on the office whiteboard.

At one point, a young, smartly dressed man opens the small package he has received at the counter to reveal a ring set with a sparkling stone: an engagement ring for his girlfriend.

He is planning to ask her to marry him a fortnight later in Paris – 1,500 miles and a world away from this suburb with its bombed-out high-rises.

Maksym Kravchenko, 28, is an anaesthetist in one of the city’s hospitals.
View image in fullscreen Maksym Kravchenko with the engagement ring delivered by Nova Poshta – he plans to propose to his girlfriend in Paris, far away from the frontline

Dobronos points out his regulars, many of whom are sustaining businesses reliant on the postal service.

Marharyta Klymova, 24, a veterinarian, is receiving some material for reconstructing her damaged premises – but she also regularly takes delivery of “meds, pills, liquids, catheters, syringes, everything.

If you don’t receive the parcel, you can’t treat the animals,” she says. “I haven’t left Kharkiv even for a day. Now, business slowly but firmly goes up. There are a lot of stressed animals here.”

Olena Marenych, 51, is sending back a hoodie she had ordered in the wrong size. “I’m super-happy here in Ukraine,” she says.

“Home is better for me, though sometimes it’s scary.” Maksym Bilous, 33, runs an online shop selling Starlink parts: “I send them all over, but mostly to the east where fighting takes place; we adapt the equipment and install it in cars.”

View image in fullscreen View image in fullscreen Top: Andrii Tomko with the textile bales he is posting to Dnipro and Zaporizhzhia; left: Olena Marenych with the hoodie she’s returning; and Olena Miroshnyk is sending out one of her gift hampers

Andrii Tomko, 24, is posting huge bales of textiles to Dnipro and Zaporizhzhia, as part of his family’s wholesale fabric business.

A couple of times he lost parcels to fire when a Nova Poshta terminal was hit by a missile. But he had been compensated, he says.

Olena Miroshnyk, 47, has a small business selling gift hampers; she is sending out several that day to customers in other parts of Ukraine.

The full-scale invasion stymied her plans to open a shop; instead she has swerved towards an online business. “It’s very difficult. Last night was difficult.

You invest a lot in a business, you risk a lot, but what can you do? We moved to Kyiv for half a year, then Poltava for half a year, but we decided to return – our own apartment is OK.”

Vita Kramarenko, 53, has also returned to Kharkiv after two years as a refugee in Germany. “I realised Ukrainian services are best,” she says.

“Despite the war, everything works and everything arrives, shelling or not. European services are a myth.”

She is sending a set of curtains and curtain rails to her sister in Spain. “It’s very expensive to buy those things there, so I am sending them to her,” she says.

View image in fullscreen The logistics hub of Nova Poshta in Kyiv. A large sign points out the location of the bomb shelters

Before the full-scale invasion, Nova Poshta operated only within Ukraine and neighbouring Moldova.
Now, initially to serve the needs of the country’s millions of refugees, it has expanded to a further 15 European countries, including Spain and the UK, where it is called Nova Post.

“Even in these tough times, it is a chance for us to become a European or global delivery company,” says Nova Poshta’s co-founder Viacheslav Klymov in an interview, saying that the company now provides next-day delivery between, for example, Warsaw and Berlin.

But the difficulties of running an efficient postal service during a full-scale invasion are enormous. “The safety of our customers and staff is the biggest challenge,” says Klymov.

Then there is the threat from Russian attacks on energy infrastructure, which has led the company to invest in becoming “energy independent” – essentially, installing generators in local branches and, at the large sorting depots, generating power from their own gas supply via co-generation plants.

When cities are otherwise plunged into darkness, Nova Poshta can keep working.
View image in fullscreen Marharyta Klimova, a vet, picking up a parcel at Nova Poshta in Kharkiv
Staffing is also a challenge: 4,000 workers, or 10% of the staff have been mobilised into the army, according to a Nova Poshta spokeswoman.

And there have been casualties, too: 22 civilian Nova Poshta employees have been killed in Russian attacks, and 218 after being drafted into the military.

The mobilisation of so many employees has provided an impetus to accelerate automation.
In a vast sorting depot near Kyiv, 1.5m parcels are processed every day, largely through automated and robotised processes: after being delivered from the local post offices, packages are moved through a dizzying set of scanners and chutes before being loaded on to lorries for the journey to their destination cities.

Klymov is speaking the morning after an attack had left much of Kyiv without electricity or water.
Nova Poshta had put out a message apologising for a possible delay to deliveries – essentially because staff had had to take refuge in bomb shelters during the night.

But the delay was expected to be counted in hours rather than days, and offices were open as usual.
“The Ukrainian customer is a very strange creature,” says Klymov.
“The Ukrainian customer doesn’t care about attacks, doesn’t care about an absence of electricity supply: the Ukrainian customer needs their delivery on time.”

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22