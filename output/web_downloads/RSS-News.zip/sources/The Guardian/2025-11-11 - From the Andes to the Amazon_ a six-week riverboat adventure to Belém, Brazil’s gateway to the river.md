---
title: "From the Andes to the Amazon: a six-week riverboat adventure to Belém, Brazil’s gateway to the river"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 16:00
url: https://www.theguardian.com/travel/2025/nov/11/andes-to-the-amazon-riverboat-adventure-to-belem-brazil-cop30
type: news-article
tags:
  - 뉴스
  - The Guardian
  - bel
  - about
  - river
  - amazon
  - tourism
  - other
  - people
  - local
authors: Kevin Rushby
---

# From the Andes to the Amazon: a six-week riverboat adventure to Belém, Brazil’s gateway to the river

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 16:00 |
| **저자** | Kevin Rushby |
| **원문링크** | [바로가기](https://www.theguardian.com/travel/2025/nov/11/andes-to-the-amazon-riverboat-adventure-to-belem-brazil-cop30) |

## 📝 요약
> <p>Visiting the city hosting the Cop30 conference brings with it questions about farming, tourism and sustainability</p><p>In an open-air market in the Brazilian city of Belém, I had a problem. It was breakfast time and I wanted a drink, but the long menu of fruit juices was baffling. Apart from pineapple (<em>abacaxi</em>) and mango (<em>manga</em>), I’d never heard of any of the drinks. What are <em>bacuri</em>, <em>buriti</em> and <em>muruci</em>? And what about <em>mangaba</em><em>, </em><em>tucumã</em> and <em>uxi</em>? Even my phone was confused. <em>Uxi</em>, it informed me, is a Zulu word meaning “you are”.</p><p>But then I started to recognise names that I’d heard on my six-week voyage from the Andes to the mouth of the Amazon. There was <em>cu</em><em>puaçu</em>. I’d picked one of those cacao-like pods in a Colombian village about 1,900 miles (3,000km) back upriver. And even further away, in Peru, there was <em>aça</em><em>í</em>: a purple berry growing high up on a wild palm. The Amazon, it seems, is vast and varied, but also remarkably similar along its astonishing length.</p> <a href="https://www.theguardian.com/travel/2025/nov/11/andes-to-the-amazon-riverboat-adventure-to-belem-brazil-cop30">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `bel` | `about` | `river`

**태그**: #bel #about #river #amazon #tourism #other

## 📰 본문

In an open-air market in the Brazilian city of Belém, I had a problem. It was breakfast time and I wanted a drink, but the long menu of fruit juices was baffling.

Apart from pineapple (abacaxi) and mango (manga), I’d never heard of any of the drinks. What are bacuri, buriti and muruci? And what about mangaba, tucumã and uxi? Even my phone was confused.

Uxi, it informed me, is a Zulu word meaning “you are”.
But then I started to recognise names that I’d heard on my six-week voyage from the Andes to the mouth of the Amazon. There was cupuaçu.

I’d picked one of those cacao-like pods in a Colombian village about 1,900 miles (3,000km) back upriver. And even further away, in Peru, there was açaí: a purple berry growing high up on a wild palm.

The Amazon, it seems, is vast and varied, but also remarkably similar along its astonishing length.
My six-week Amazon adventure had begun with a conference on sustainable tourism in Peru.
It was 2023 and Belém, on the other side of South America, had been declared the location for the Cop30 conference.

Determined to cut down on air miles, I set off downriver, heading towards Belém, using public river boats, all the time seeking out people who were working to preserve this incredible environment.

I did night walks with guides who blasted powdered concoctions up my nose to make me “alert” (not that kind of concoction – herbal stuff).

I swam across the river (then enjoyed lots of electric eel stories) and repeatedly had the disorienting experience of not knowing which country I was in.

Until I reached Manaus, I met only a handful of visitors, but I was always wondering about tourism and its potential role in the Amazonian future.

The idea that tourism might help in the battles against the climate crisis and biodiversity loss is one fraught with problems. Flying is the most CO 2 -intensive way of travelling. Tourism is a luxury.

Surely the only way to save the planet is to stop privileged outsiders flying around the globe, especially for self-indulgent rainforest tours?

The ranching life for these people is brutally hard and unrewarding. They want a way out, but are trapped in a cycle of deforestation

On the Mamori, a tributary of the great river in central Brazil, surrounded by the smoke from forest fires, I was given a salutary answer to this by a schoolboy. “My father is a rancher,” he told me.

“We burn the forest to get grass to feed our cattle. In emergencies we can also sell the cleared land, but not the jungle. That’s worthless.

But I don’t want to be a rancher, I want to be a tour guide.”
View image in fullscreen An old port area of Belém. Photograph: Ricardo Lima/Getty Images
When I later met his school teacher, he confirmed that other local teenagers felt the same.
“To be honest, this generation don’t want the hard physical work of clearing land; they’d prefer tourism jobs.

The problem is we don’t get many visitors and never see any NGOs or nature projects.” The ranching life for these people is brutally hard and unrewarding.

They want a way out, but are trapped in a cycle of deforestation.
Açaí is making good money for small farmers. They can grow it around their houses mixed in with other trees

Back in Belém, having downed my juice, I moved on through the market, looking for food. My local guide was Junior who recommended the local favourite: fried fish and açaí berry sauce.

“Açaí is making good money for small farmers,” he told me. “They can grow it around their houses mixed in with other trees.”

In the Peruvian village where I had first come across açaí, the people explained that the fruit had only ever been an “emergency” wild food for them, but they were happy to find that it now commanded good prices.

Their old way of life, hunting river turtles, had ended because of declining numbers and a government ban. Poaching inside the national park had been the only alternative until açaí saved them.

Junior and I went off to explore the various river islands beyond the Belém waterfront, heading for the tiny green atoll of Ilha do Combu.

The little wooden ferry took us up a narrow creek lined with abundant vegetation and watchful kingfishers where we met Charles, who runs a small handicraft shop and sells his own açaí.

“It goes with anything,” he told me. “We can eat it with fish or make ice-cream.”
View image in fullscreen Ilha do Cumbu, off Belém. Photograph: Kevin Rushby
We walked through mixed groves of palms, cacao and dozens of other tree varieties. Up above, scarlet macaws clattered around and a family of giant fruit bats complained about the noise.

This productive mosaic is a way to provide income and benefit nature. I picked up a beautiful seed the size of an egg. “Rubber,” said Charles, “We do collect it, but not in commercial quantities.”

skip past newsletter promotion Sign up to The Traveller Free newsletter Get travel inspiration, featured trips and local tips for your next break, as well as the latest deals from Guardian Holidays Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion
In the second half of the 19th century, the discovery of rubber triggered a catastrophic series of events that still haunt the Amazon. Hailed as a wonder product, it started an exploitation stampede.

Fortunes were made. At Iquitos, 2,700 miles upriver from Belém, merchants imported bottled drinking water from Belfast and sent their laundry to Lisbon.

View image in fullscreen Harvesting açaí berries involves having a head for heights. Photograph: Kevin Rushby

For most Amazonian people, however, rubber was a disaster. Forced into ever harsher labour conditions, tribes became dispersed and broken, their languages and cultures mangled.

After seeds were smuggled out to Asia in 1876 – via Kew Gardens, where they were germinated – the boom ended, but the aftermath was bitter resentment and suspicion.

Açaí has not had the same impact, but is not without controversies. Overblown hyperbole about superfoods has dented its reputation. On Ilha do Combu, however, Charles wasn’t worried.

Local demand was strong and prices good.
Next day, I took the ferry out to Ilha Cotijuba near the mouth of the river. The Amazon had one last novelty to impress me with. On the far side of the island I found a small cafe on a beach.

The owner, Lena, served a delicious lunch: river fish baked in banana leaves, a pineapple ceviche and a dessert with some pale green berries that I’ve never seen before.

“Like açaí,” she told me. “But different.”
Hidden away on those islands, the Amazon still holds secrets.
The trip was provided by sustainable tourism specialist Sumak Travel, which offers tailor-made trips to Brazil and the rest of Latin America

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22