---
title: "‘Fashion exposes people’s desires and anxieties’: how much do we really reveal when we get dressed?"
source: The Guardian
date: 2025-11-11
datetime: 2025-11-11 22:25
url: https://www.theguardian.com/fashion/2025/nov/11/fashion-exhibition-fit-new-york-dress-dreams-and-desire
type: news-article
tags:
  - 뉴스
  - The Guardian
  - steele
  - fashion
  - says
  - clothes
  - women
  - dress
  - which
  - skin
authors: Edward Helmore
---

# ‘Fashion exposes people’s desires and anxieties’: how much do we really reveal when we get dressed?

| 속성 | 값 |
| --- | --- |
| **출처** | [[The Guardian]] |
| **날짜** | 2025-11-11 22:25 |
| **저자** | Edward Helmore |
| **원문링크** | [바로가기](https://www.theguardian.com/fashion/2025/nov/11/fashion-exhibition-fit-new-york-dress-dreams-and-desire) |

## 📝 요약
> <p>A new exhibition – with contributions from Chanel, McQueen and Galliano – places 100 looks under the psychoanalytic lens, and suggests that what we wear is the result of a battle in the psyche</p><p>When you picked out an outfit this morning, did it feel like free will? Was it a series of deliberate choices that made it desirable to venture out into the world wearing said garment? Or was your decision a response to deeper subconscious forces? What if the choices we make about clothes are not our own conscious choices to make?</p><p>That’s the premise of a new exhibition in New York. Dress, Dreams and Desire: Fashion and Psychoanalysis, at the Fashion Institute of Technology, that makes the case that clothes are the “deep surface”, the “changeable, renewable second skin”, that outside the merely practical act as a facade for far more than we know.</p> <a href="https://www.theguardian.com/fashion/2025/nov/11/fashion-exhibition-fit-new-york-dress-dreams-and-desire">Continue reading...</a>

## 🏷️ 키워드
**영문 키워드**: `steele` | `fashion` | `says`

**태그**: #steele #fashion #says #clothes #women #dress

## 📰 본문

When you picked out an outfit this morning, did it feel like free will? Was it a series of deliberate choices that made it desirable to venture out into the world wearing said garment?

Or was your decision a response to deeper subconscious forces? What if the choices we make about clothes are not our own conscious choices to make?

That’s the premise of a new exhibition in New York.
Dress, Dreams and Desire: Fashion and Psychoanalysis, at the Fashion Institute of Technology, that makes the case that clothes are the “deep surface”, the “changeable, renewable second skin”, that outside the merely practical act as a facade for far more than we know.

As Dr Valerie Steele, the curator known as “the Freud of fashion”, puts it, fashion “communicates our unconscious desires and anxieties, with none of us fully aware of the messages we send.” From her perspective, “far from being superficial, fashion exposes people’s desires and anxieties like a psychosomatic rash.”

We live in a society where the body needs to be constantly dressed and the outfit becomes part of the skin we inhabit

For psychoanalysts, fashion has always been a canvas for deeper exploration.
Sigmund Freud didn’t discuss clothes in his work, and was fairly buttoned up in his own choices, but in letters to his wife, Martha Bernays, he revealed an opinion that women used “frivolous and fancy dress” to display their bodies, while men exhibited “passive exhibitionism” with hats and coats as stand-ins for male sexuality.

Follower Carl Jung argued that clothes act as a psychological “mask”, a compromise that we make between our inner self and the external display we put on to the world.

But Jacques Lacan, a French psychoanalyst close to the surrealists, went further. He argued that identity is not conscious freedom: it is formed beneath the surface, in the psyche.

For Lacanian psychoanalyst Dr Patricia Gherovici, who consulted on the exhibition: “fashion is a way of dressing up the death drive”.

As well, she says, as there being “something in making our mortal bodies look a little better.”
This show, which Steele spent five years putting together, places 100 looks under the psychoanalytic lens, from the 19th century to the present.

Displays include designs by Elsa Schiaparelli, Coco Chanel, Alexander McQueen, and John Galliano, who designed a “Freud to Fetish” collection for Dior in 2000.

“We live in a society where the body needs to be constantly dressed and the outfit becomes part of the skin we inhabit,” says Steele.

“The determinations we make come with conscious – and unconscious – intentions that carry enormous transformative power.” In other words, to telegraph to ourselves and others who we are and who we may desire to be; it’s just a primal battle in the psyche playing out.

View image in fullscreen Elsa Schiaparelli’s evening jacket has embroidered rococo hand mirrors. Photograph: Katrina Lawson Johnston/© Francesca Galloway

But the exhibition argues that this analytical approach also comes from the designer, with some actively deploying psychoanalytic curiosity into their clothes.

McQueen’s 1998 Joan [of Arc] told the story of the Catholic martyr who was burned at the stake soon after refusing to wear women’s clothes; and 2007’s Witches and Persecution featured dresses referencing the violent ritual of shaving the hair of women found guilty of witchcraft prior to execution.

While some have accused him of misogyny – the exhibition notes include a reference to psychoanalyst Edmund Bergler who described gay male fashion designers, such as McQueen, as “women’s bitterest enemies” – Lacanians, according to Steele, “tend to argue his fashions were empowering”.

Perhaps no designer drank more deeply from the font of psychoanalysis than Elsa Schiaparelli, who was friends with psychoanalysts, including Lacan, as well as psychoanalytically inspired surrealists Salvador Dalí, Jean Cocteau, and Alberto Giacometti.

For this exhibition, Steele chose an evening jacket with embroidered rococo hand mirrors with fractured faces – Schiaparelli’s designs often used mirrors.

It’s no big leap from here to Lacan’s theory of the Mirror Stage, in which a child first begins to recognise itself in the gaze of the mother.

“Lacan’s idea is that self-image is based on how other people look at you, starting with your mother,” says Steele.

And Schiaparelli was certainly dealing with issues born out of a critical mother’s gaze. “Her mother told her repeatedly that she was ugly.”

Interestingly, Steele, until now, has often addressed clothing through the lens of sexuality and gender. “But now,” she says, “I’m much more conscious of how they’re used to conceal vulnerabilities.”

View image in fullscreen Multidisciplinary artist Jenni Dutton’s dress made from hair. Photograph: Eileen Costa/© The Museum at FIT

Among the pieces, there’s also a short, reddish-brown dress by multidisciplinary artist Jenni Dutton made from hair, which Steele had created for the show.

Hair can be “very freaky for people, especially if it’s in the wrong place,” she says, before offering a psychosexual, Freudian interpretation of the dress’s hypothetical wearer as signalling, by clothing themselves in nothing but hair, that they want, in fact, to be naked.

Most people, it’s fair to say, absolutely don’t want to be naked in public, but the question of how much nudity is in fashion at any given moment, how much you or I decide to flash or conceal, has deeper levels to unpack.

The rise of nude fashion now, says Steele, may be a response to Ozempic moving the needle back on body positivity, as well as carrying a strong political charge against authoritarianism.

Then there’s a teal-coloured, cinched-waist dress by Anne Fogarty, a US designer from the 1950s, which speaks to mid-century ideas of gender construction but also offers a prism through which to think about the contemporary trad-wife trend.

According to Steele, psychoanalyst Joan Riviere “spoke of a feminine masquerade to reassure men they are not really powerful and dangerous,” Steele says.” “When you talk about women masquerading as women you’re really in the realm of fashion,” says Steele.

skip past newsletter promotion Sign up to Fashion Statement Free weekly newsletter Style, with substance: what's really trending this week, a roundup of the best fashion journalism and your wardrobe dilemmas solved Enter your email address Sign up Privacy Notice: Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on Newsletters may contain information about charities, online ads, and content funded by outside parties.

If you do not have an account, we will create a guest account for you on theguardian.com to send you this newsletter. You can complete full registration at any time.

For more information about how we use your data see our Privacy Policy . We use Google reCaptcha to protect our website and the Google Privacy Policy and Terms of Service apply.

after newsletter promotion
It’s this skill for seeing clothes through the prism of analysts that gives Steele a fresh and intellectual take on current trends – a manifestation of that desire for a changeable new skin, which the exhibition describes as where “unconscious emotions and fantasies take symbolic form”.

There’s no discussion of fashion and psychoanalysis that leaves out the phallus.
Freud started it with his theories of the oedipal complex and the phallic stage of psychosexual development, but Lacan took it further positing that neither sex possesses it.

Steele paraphrases: “Men think their penis is the phallus, and they hope it is, but women embody the phallus.”

Nowhere is this more prescient, fashion-wise, than in high heels.
It’s not, says Steele, that women opting for stilettos are “collecting phallic symbols, nor is it they’re dressing up in fetish clothes for men.

Men may be out there fetishising all over the place, but what are women doing? Every dominatrix I’ve spoken to says they are to show who is in charge.”

Of course all of this – our “renewable second skin” – is always changing, and the problematic nub of our metamorphosing desires is their toll on the environment.

Steele says there’s a tension here, which leaves fashion consumers in a psychoanalytic predicament.
The desire to shop, or rather to clothe in a metamorphosing second skin is according to Steele, a consumerist embodiment of the sex drive, or Freud’s Eros.

But Eros is in conflict with Thanatos, the death drive; in this case the knowledge of the real-world ecological implications of consumerism. It’s hard to say which will win out, Steele acknowledges.

Perhaps neither.
“Many people who love fashion are also feeling hostile to it, in part because they see it as part of the destruction of the Earth,” says Steele.

“I’m starting to feel like there’s some huge death drive, with people unwilling or feeling powerless to stop it, but they also want novelty, because a new dress is like a new skin.”

If psychoanalysis can help us understand the root of our shopping habit, perhaps it can help us kick it. But we’re still none the wiser how to make sure, once and for all, that we picked our clothes.

Dress, Dreams and Desire: Fashion and Psychoanalysis at The Museum at FIT is on now until the 4th January 2026.

## 📅 관련 노트
- 일간 정리: [[2025-11-11]]
- 출처별 정리: [[출처 - The Guardian]]

생성일시: 2025-11-14 15:53:22