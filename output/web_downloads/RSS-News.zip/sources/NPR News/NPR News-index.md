---
title: NPR News 뉴스
source: NPR News
type: source-index
tags: [뉴스, 소스별정리]
---

# 📺 NPR News

**총 기사 수**: 6개

## 2025-11-12
- [New Epstein emails appears to reveal more Trump ties](https://www.npr.org/2025/11/12/nx-s1-5605582/epstein-files-release-trump-email-grijalva-massie)
- [Flight issues could linger after shutdown. And, Google's lawsuit targeting scammers](https://www.npr.org/2025/11/12/g-s1-97550/up-first-newsletter-house-shutdown-vote-air-traffic-control-uss-ford-google)
- [They found a 'bucket of lentils.' Then it blew up. The menace of Gaza's unexploded ordnance](https://www.npr.org/2025/11/12/g-s1-96887/gaza-unexploded-ordnance-uxo-israel)
- [Adelita Grijalva is set to be sworn in, teeing up a potential vote on Epstein files](https://www.npr.org/2025/11/12/nx-s1-5606350/adelita-grijalva-swearing-in)
- [Google launches a lawsuit targeting text message scammers](https://www.npr.org/2025/11/12/nx-s1-5604857/google-lawsuit-phishing-text-message-scammers)
- ['Where do you want to go?': Six words that helped her start again](https://www.npr.org/2025/11/12/nx-s1-5604852/depression-unsung-hero)
